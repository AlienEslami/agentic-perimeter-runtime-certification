LATEX PACKAGE - COMPLETE AND REDUCED PAPERS

Title: Formal Guarantees for Trustworthy Agent-Mediated Urban Perimeter Control
Revision: 16 October 2026, after the prose and plan-expiry clarification.

MAIN DOCUMENTS
main.tex          Complete version (81 pages in the verified build).
main_reduced.tex  Reduced version (47 pages in the verified build).

OVERLEAF
Upload this ZIP as a new project. In the project settings, choose either
main.tex or main_reduced.tex as the Main document. Select pdfLaTeX as the
compiler. Switch the Main document to compile the other version.

CONTENTS
Both manuscript sources, their declaration files, the shared bibliography,
prebuilt bibliography files, and all figures used by either manuscript.
Keep the figures folder and declaration filenames unchanged.
The elsarticle class, elsarticle-num bibliography style and glyphtounicode
file are standard TeX-distribution files supplied by Overleaf.

LOCAL COMPILATION
Use a TeX distribution with elsarticle and the packages listed in the sources.
For the complete version, run:
  pdflatex main
  bibtex main
  pdflatex main
  pdflatex main
For the reduced version, replace main with main_reduced in all four commands.
