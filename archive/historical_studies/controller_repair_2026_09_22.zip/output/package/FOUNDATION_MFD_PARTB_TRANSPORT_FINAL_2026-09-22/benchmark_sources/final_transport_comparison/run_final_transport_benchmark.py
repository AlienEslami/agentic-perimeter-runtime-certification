"""Matched transportation benchmark for the final Part-B manuscript.

This script adds the declared Zhong-style CLF+queue extension to the same
minute-20 priority/deadline witness used by the economic MPC, predictive
repair, and verified backup.  It then assembles that result with the existing
eight-event incident-severity sweep.  The CBF diagnostic is deliberately not
included in the manuscript comparison.
"""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parents[1]
COMMON = HERE.parent / "common_plant"
if str(COMMON) not in sys.path:
    sys.path.insert(0, str(COMMON))

import mfd_incident_model as plant  # noqa: E402
import mfd_incident_mpc as mpc  # noqa: E402


RESULTS = HERE / "results"
WITNESS = PACKAGE / "evidence/cbf_certified_mpc/economic_mpc_plan_witness.json"
REPAIR = PACKAGE / "evidence/cbf_certified_mpc/deadline_predictive_filter.json"
SEVERITY = PACKAGE / "evidence/zhong2018_clf/matched_clf_mpc_comparison.json"
REGION2_ROW = np.array([1.0, 4.0, 0.0, 0.0, 0.0, 0.0, 1.0])
START_H = 1.0 / 3.0
END_H = 1.0
SERVICE_LIMIT = 2850.0
RESIDUAL_UNITS_H = 3.0


def almost_smooth_correction(alpha: float, beta: np.ndarray) -> np.ndarray:
    squared_norm = float(beta @ beta)
    if squared_norm <= np.finfo(float).eps:
        return np.zeros_like(beta)
    multiplier = -(alpha + np.sqrt(alpha * alpha + squared_norm * squared_norm)) / (
        squared_norm * (1.0 + np.sqrt(1.0 + squared_norm))
    )
    return multiplier * beta


class ClfQueueExtension:
    """Zhong-style cross-gate CLF with the declared queue/exit LQR extension."""

    def __init__(self, lower: float = 0.0, upper: float = 1.0):
        self.mode = plant.synthesize(
            "region1_protection",
            27.0,
            32.0,
            (4.0, 1.0, 0.1, 0.1, 0.1, 0.1, 2.0),
            3000.0,
        )
        self.lower = lower
        self.upper = upper

    def command(self, state: np.ndarray, offered_arrival: float) -> np.ndarray:
        state = np.asarray(state, dtype=float)
        reference = self.mode.feedforward.copy()
        command = self.mode.command(state)
        error_vehicles = 100.0 * (state[:2] - self.mode.center[:2])
        drift_veh_s = (100.0 / 3600.0) * plant.field(
            state, reference, offered_arrival
        )[:2]
        n1, n2, n11, n22, n10, n20, _queue = state
        n12 = n1 - n11 - n10
        n21 = n2 - n22 - n20
        q12_plus_q10 = plant.original.class_flow(n12 + n10, n1)
        q21 = plant.original.class_flow(n21, n2)
        gate_directions = (100.0 / 3600.0) * np.array(
            [[-q12_plus_q10, q21], [q12_plus_q10, -q21]]
        )
        alpha = float(error_vehicles @ drift_veh_s)
        beta = gate_directions.T @ error_vehicles
        correction = almost_smooth_correction(alpha, beta)
        command[:2] = reference[:2] + np.clip(
            correction,
            self.lower - reference[:2],
            self.upper - reference[:2],
        )
        difference = command[1] - command[0]
        if abs(difference) > 0.75:
            midpoint = 0.5 * (command[0] + command[1])
            signed_half_width = 0.375 * np.sign(difference)
            command[0] = midpoint - signed_half_width
            command[1] = midpoint + signed_half_width
        return command


def priority_cost(trajectory: dict) -> float:
    times = np.asarray(trajectory["time_h"], dtype=float)
    states = np.asarray(trajectory["state"], dtype=float)
    return float(np.trapezoid(100.0 * states @ REGION2_ROW, times))


def simulate(x0, command_at, actual_arrival, label):
    """Replay one policy on the common plant at the archived 10-second step."""
    x = np.asarray(x0, dtype=float).copy()
    states, times, commands = [x.tolist()], [START_H], []
    tts = queue_hours = departures = 0.0
    max_queue = float(x[6])
    minimum_margin = np.inf
    for step in range(round((END_H - START_H) / mpc.EXECUTION_STEP)):
        time_h = START_H + step * mpc.EXECUTION_STEP
        command = np.asarray(command_at(time_h, x), dtype=float)
        new = plant.rk4(
            x,
            lambda _state, held=command: held,
            time_h,
            mpc.EXECUTION_STEP,
            actual_arrival,
        )
        minimum_margin = min(
            minimum_margin,
            float(np.min(plant.margins(x, command))),
            float(np.min(plant.margins(new, command))),
        )
        max_queue = max(max_queue, float(new[6]))
        h = mpc.EXECUTION_STEP
        both = x + new
        tts += h * 50.0 * float(mpc.COST_ROW @ both)
        queue_hours += h * 50.0 * float(both[6])
        departures += h * 50.0 * float(
            plant.departure_rate(x, command) + plant.departure_rate(new, command)
        )
        x = new
        times.append(time_h + h)
        states.append(x.tolist())
        commands.append(command.tolist())
    return {
        "policy": label,
        "metrics": {
            "suffix_tts_veh_h": tts,
            "suffix_queue_veh_h": queue_hours,
            "suffix_departures_vehicles": departures,
            "max_queue_vehicles": 100.0 * max_queue,
            "storage_safe": bool(max_queue <= plant.QUEUE_LIMIT + 1e-8),
            "first_storage_overflow_minutes": None,
            "minimum_sampled_physical_margin": minimum_margin,
            "deadline_region1_vehicles": 100.0 * float(x[0]),
            "service_limit_vehicles": SERVICE_LIMIT,
            "service_pass": bool(100.0 * x[0] <= SERVICE_LIMIT + 1e-8),
            "service_margin_vehicles": SERVICE_LIMIT - 100.0 * float(x[0]),
            "intervention_steps": 0,
            "maximum_command_correction": 0.0,
        },
        "trajectory": {"time_h": times, "state": states, "command": commands},
    }


def run_priority_clf() -> dict:
    witness = json.loads(WITNESS.read_text(encoding="utf-8"))
    initial_state = np.asarray(witness["scenario"]["initial_state"], dtype=float)
    actual_arrival = lambda time_h: mpc.arrival(time_h) + RESIDUAL_UNITS_H
    policy = ClfQueueExtension()

    def command_at(time_h: float, state: np.ndarray):
        return policy.command(state, actual_arrival(time_h))

    result = simulate(
        initial_state,
        command_at,
        actual_arrival,
        "zhong_style_clf_plus_declared_queue_extension",
    )
    result["metrics"]["region2_priority_cost"] = priority_cost(result["trajectory"])
    result["scope"] = {
        "same_seven_state_plant": True,
        "same_initial_information_witness": True,
        "same_arrival_residual_veh_h": 100.0 * RESIDUAL_UNITS_H,
        "published_controller_unchanged": False,
        "reason": (
            "The published two-gate model has no exterior queue or admission/exit "
            "channels; the cross-gate CLF is combined with the declared matched LQR extension."
        ),
    }
    return result


def normalized_row(label: str, policy: dict) -> dict:
    metrics = dict(policy["metrics"])
    if "region2_priority_cost" not in metrics:
        metrics["region2_priority_cost"] = priority_cost(policy["trajectory"])
    return {
        "policy": label,
        "suffix_tts_veh_h": metrics["suffix_tts_veh_h"],
        "peak_queue_vehicles": metrics["max_queue_vehicles"],
        "deadline_region1_vehicles": metrics["deadline_region1_vehicles"],
        "storage_pass": bool(metrics["storage_safe"]),
        "service_pass": bool(metrics["service_pass"]),
        "region2_priority_cost": metrics["region2_priority_cost"],
        "service_margin_vehicles": metrics["service_margin_vehicles"],
    }


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    clf = run_priority_clf()
    (RESULTS / "priority_conflict_clf.json").write_text(
        json.dumps(clf, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )

    witness = json.loads(WITNESS.read_text(encoding="utf-8"))
    witness_by_name = {item["policy"]: item for item in witness["policies"]}
    repair = json.loads(REPAIR.read_text(encoding="utf-8"))["realization"]
    rows = [
        normalized_row(
            "Uncertified economic MPC",
            witness_by_name["unfiltered_economic_mpc_plan"],
        ),
        normalized_row("Zhong-style CLF + queue extension", clf),
        normalized_row("Certified predictive repair", repair),
        normalized_row(
            "Verified continuation",
            witness_by_name["plan_certificate_with_retained_verified_suffix"],
        ),
    ]

    severity = json.loads(SEVERITY.read_text(encoding="utf-8"))
    payload = {
        "study": "final matched transportation benchmark",
        "priority_conflict": {
            "source_event": "adverse25 affine run, epoch 4 (minute 20)",
            "same_plant_state_demand_and_contract": True,
            "service_limit_vehicles": SERVICE_LIMIT,
            "rows": rows,
        },
        "incident_severity_sweep": {
            key: severity[key]
            for key in (
                "scope",
                "baseline_label",
                "all_clf_runs_physically_completed",
                "clf_deadline_passes",
                "certified_mpc_deadline_passes",
                "minimum_tts_reduction_percent",
                "median_tts_reduction_percent",
                "maximum_tts_reduction_percent",
                "rows",
            )
        },
        "claim_boundary": (
            "The common-plant CLF row is a declared queue/exit extension of the "
            "published two-gate controller. The comparison evaluates the added "
            "queue and scheduled-service task on the manuscript plant."
        ),
    }
    output_json = RESULTS / "final_transport_benchmark.json"
    output_json.write_text(
        json.dumps(payload, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )
    output_csv = RESULTS / "priority_conflict_comparison.csv"
    with output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(payload["priority_conflict"], indent=2), flush=True)
    print(output_json, flush=True)


if __name__ == "__main__":
    main()
