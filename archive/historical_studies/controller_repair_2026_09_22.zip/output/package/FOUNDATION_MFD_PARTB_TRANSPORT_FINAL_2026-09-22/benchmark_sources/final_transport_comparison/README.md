# Final matched transportation benchmark

This benchmark assembles only transportation-relevant comparators for the
Part-B manuscript. It adds the declared Zhong-style CLF+queue extension to the
same minute-20 priority/deadline witness used for economic MPC, predictive
repair, and the verified continuation. It also imports the existing matched
20--40% incident-severity sweep.

Run:

```powershell
python run_final_transport_benchmark.py
```

The CBF diagnostic remains in `benchmarks/cbf_certified_mpc` and is excluded
from the final manuscript comparison.
