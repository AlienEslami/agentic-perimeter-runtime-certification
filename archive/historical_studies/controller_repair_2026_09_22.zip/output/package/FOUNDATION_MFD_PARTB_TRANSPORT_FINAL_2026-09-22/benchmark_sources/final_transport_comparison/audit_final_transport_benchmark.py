"""Independent numerical audit of the final transportation benchmark."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
COMMON = HERE.parent / "common_plant"
if str(COMMON) not in sys.path:
    sys.path.insert(0, str(COMMON))

import mfd_incident_model as plant  # noqa: E402
import mfd_incident_mpc as mpc  # noqa: E402


RESULT = HERE / "results/final_transport_benchmark.json"
CLF = HERE / "results/priority_conflict_clf.json"
AUDIT = HERE / "results/audit.json"
REGION2_ROW = np.array([1.0, 4.0, 0.0, 0.0, 0.0, 0.0, 1.0])


def close(left: float, right: float, atol: float = 1e-8) -> bool:
    return bool(abs(left - right) <= atol * max(1.0, abs(left), abs(right)))


def main() -> int:
    result = json.loads(RESULT.read_text(encoding="utf-8"))
    clf = json.loads(CLF.read_text(encoding="utf-8"))
    metrics = clf["metrics"]
    trajectory = clf["trajectory"]
    times = np.asarray(trajectory["time_h"], dtype=float)
    states = np.asarray(trajectory["state"], dtype=float)
    commands = np.asarray(trajectory["command"], dtype=float)
    recomputed_tts = float(np.trapezoid(100.0 * states @ mpc.COST_ROW, times))
    recomputed_priority = float(np.trapezoid(100.0 * states @ REGION2_ROW, times))
    recomputed_queue = 100.0 * float(np.max(states[:, 6]))
    recomputed_deadline = 100.0 * float(states[-1, 0])
    minimum_margin = np.inf
    for index, command in enumerate(commands):
        minimum_margin = min(
            minimum_margin,
            float(np.min(plant.margins(states[index], command))),
            float(np.min(plant.margins(states[index + 1], command))),
        )

    rows = {row["policy"]: row for row in result["priority_conflict"]["rows"]}
    repair = rows["Certified predictive repair"]
    nominal = rows["Uncertified economic MPC"]
    backup = rows["Verified continuation"]
    clf_row = rows["Zhong-style CLF + queue extension"]
    priority_denominator = backup["region2_priority_cost"] - nominal["region2_priority_cost"]
    retained_priority_fraction = (
        backup["region2_priority_cost"] - repair["region2_priority_cost"]
    ) / priority_denominator
    repair_tts_reduction_vs_clf = 100.0 * (
        clf_row["suffix_tts_veh_h"] - repair["suffix_tts_veh_h"]
    ) / clf_row["suffix_tts_veh_h"]

    checks = {
        "clf_tts_recomputed": close(recomputed_tts, metrics["suffix_tts_veh_h"]),
        "clf_priority_cost_recomputed": close(recomputed_priority, metrics["region2_priority_cost"]),
        "clf_peak_queue_recomputed": close(recomputed_queue, metrics["max_queue_vehicles"]),
        "clf_deadline_recomputed": close(recomputed_deadline, metrics["deadline_region1_vehicles"]),
        "clf_physical_rows_satisfied": minimum_margin >= -1e-8,
        "four_priority_policies_present": len(rows) == 4,
        "nominal_fails_both_contract_rows": not nominal["storage_pass"] and not nominal["service_pass"],
        "clf_passes_both_contract_rows": clf_row["storage_pass"] and clf_row["service_pass"],
        "repair_passes_both_contract_rows": repair["storage_pass"] and repair["service_pass"],
        "backup_passes_both_contract_rows": backup["storage_pass"] and backup["service_pass"],
        "repair_lower_tts_than_clf": repair["suffix_tts_veh_h"] < clf_row["suffix_tts_veh_h"],
        "repair_better_priority_tracking_than_clf": repair["region2_priority_cost"] < clf_row["region2_priority_cost"],
        "repair_better_priority_tracking_than_backup": repair["region2_priority_cost"] < backup["region2_priority_cost"],
        "eight_severity_cases_present": len(result["incident_severity_sweep"]["rows"]) == 8,
        "severity_amplitudes_cover_20_to_40_percent": (
            min(row["amplitude"] for row in result["incident_severity_sweep"]["rows"]) == 0.2
            and max(row["amplitude"] for row in result["incident_severity_sweep"]["rows"]) == 0.4
        ),
    }
    report = {
        "passed": all(checks.values()),
        "checks": checks,
        "recomputed": {
            "clf_suffix_tts_veh_h": recomputed_tts,
            "clf_region2_priority_cost": recomputed_priority,
            "clf_peak_queue_vehicles": recomputed_queue,
            "clf_deadline_region1_vehicles": recomputed_deadline,
            "clf_minimum_physical_margin": minimum_margin,
            "repair_priority_benefit_retained_relative_to_backup": retained_priority_fraction,
            "repair_tts_reduction_vs_clf_percent": repair_tts_reduction_vs_clf,
        },
    }
    AUDIT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
