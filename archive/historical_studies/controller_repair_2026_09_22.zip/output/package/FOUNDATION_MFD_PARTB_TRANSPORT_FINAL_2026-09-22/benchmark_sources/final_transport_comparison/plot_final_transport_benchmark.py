"""Create the final matched transportation benchmark figure."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RESULTS = HERE / "results"
WITNESS = ROOT / "benchmarks/cbf_certified_mpc/results/economic_mpc_plan_witness.json"
REPAIR = ROOT / "benchmarks/cbf_certified_mpc/results/deadline_predictive_filter.json"
GRID = ROOT / "benchmarks/cbf_certified_mpc/results/predictive_repair_path_audit.json"
CLF = RESULTS / "priority_conflict_clf.json"
FINAL = RESULTS / "final_transport_benchmark.json"


def series(record: dict) -> tuple[np.ndarray, np.ndarray]:
    trajectory = record["trajectory"]
    return 60.0 * np.asarray(trajectory["time_h"]), 100.0 * np.asarray(trajectory["state"])


def main() -> None:
    witness = json.loads(WITNESS.read_text(encoding="utf-8"))
    policies = {item["policy"]: item for item in witness["policies"]}
    repair = json.loads(REPAIR.read_text(encoding="utf-8"))["realization"]
    clf = json.loads(CLF.read_text(encoding="utf-8"))
    final = json.loads(FINAL.read_text(encoding="utf-8"))
    grid = json.loads(GRID.read_text(encoding="utf-8"))["rows"]

    trajectories = [
        ("Rejected MPC", policies["unfiltered_economic_mpc_plan"], "#c44e52", "--"),
        ("CLF + queue", clf, "#4c72b0", "-"),
        ("Certified repair", repair, "#55a868", "-"),
        ("Verified continuation", policies["plan_certificate_with_retained_verified_suffix"], "#555555", "-"),
    ]

    plt.rcParams.update({
        "font.family": "serif",
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "legend.fontsize": 8,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })
    fig, axes = plt.subplots(2, 2, figsize=(10.8, 7.0), constrained_layout=True)

    ax = axes[0, 0]
    for label, record, color, style in trajectories:
        time, state = series(record)
        ax.plot(time, state[:, 0], color=color, linestyle=style, linewidth=1.7, label=label)
    ax.axhline(2850.0, color="black", linewidth=1.0, linestyle=":", label="Deadline limit")
    ax.axvline(60.0, color="0.55", linewidth=0.9, linestyle=":")
    ax.set_title("(a) Region-1 accumulation")
    ax.set_xlabel("Time (min)")
    ax.set_ylabel("Vehicles")
    ax.set_xlim(20, 60)
    ax.grid(alpha=0.22)
    ax.legend(ncol=2, loc="best")

    ax = axes[0, 1]
    for label, record, color, style in trajectories:
        time, state = series(record)
        ax.plot(time, state[:, 6], color=color, linestyle=style, linewidth=1.7, label=label)
    ax.axhline(2000.0, color="black", linewidth=1.0, linestyle=":", label="Storage limit")
    ax.set_title("(b) Exterior queue")
    ax.set_xlabel("Time (min)")
    ax.set_ylabel("Vehicles")
    ax.set_xlim(20, 60)
    ax.grid(alpha=0.22)

    ax = axes[1, 0]
    rows = final["priority_conflict"]["rows"]
    names = ["MPC", "CLF", "Repair", "Backup"]
    tts = np.array([row["suffix_tts_veh_h"] for row in rows])
    priority = np.array([row["region2_priority_cost"] for row in rows])
    x = np.arange(len(rows))
    width = 0.36
    ax.bar(x - width / 2, 100.0 * tts / tts[0], width, color="#4c72b0", label="TTS / MPC")
    ax.bar(x + width / 2, 100.0 * priority / priority[0], width, color="#dd8452", label="$J_2$ / MPC")
    ax.axhline(100.0, color="0.4", linewidth=0.8, linestyle=":")
    ax.set_xticks(x, names)
    ax.set_ylabel("Percent of rejected-MPC value")
    ax.set_title("(c) Cost and priority tracking")
    ax.grid(axis="y", alpha=0.22)
    ax.legend(loc="best")

    ax = axes[1, 1]
    theta = np.array([row["theta"] for row in grid])
    accepted = np.array([row["accepted"] for row in grid], dtype=bool)
    ax.scatter(theta[~accepted], np.zeros(np.sum(~accepted)), marker="x", s=44, color="#c44e52", label="Rejected")
    ax.scatter(theta[accepted], np.ones(np.sum(accepted)), marker="o", s=28, facecolor="#55a868", edgecolor="black", linewidth=0.35, label="Certified")
    ax.axvline(0.2822265625, color="black", linewidth=0.9, linestyle=":", label="Selected repair")
    ax.set_yticks([0, 1], ["Rejected", "Certified"])
    ax.set_xlabel("Interpolation toward verified continuation, $\\vartheta$")
    ax.set_title("(d) Ordered repair grid")
    ax.set_xlim(-0.02, 1.02)
    ax.set_ylim(-0.3, 1.3)
    ax.grid(axis="x", alpha=0.22)
    ax.legend(loc="lower right")

    fig.savefig(RESULTS / "final_transport_benchmark.pdf", bbox_inches="tight")
    fig.savefig(RESULTS / "final_transport_benchmark.png", dpi=220, bbox_inches="tight")


if __name__ == "__main__":
    main()
