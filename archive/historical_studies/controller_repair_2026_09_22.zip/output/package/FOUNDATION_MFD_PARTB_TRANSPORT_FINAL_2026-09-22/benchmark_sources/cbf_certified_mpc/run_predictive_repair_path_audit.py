"""Audit certification and performance along the MPC-to-backup repair path."""
from __future__ import annotations

from fractions import Fraction
import json
import sys
import time
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE_ROOT = ROOT / "output/package/FOUNDATION_MFD_PARTB_REVIEWED_2026-09-11_TASK-NETWORK"
SOURCE = SOURCE_ROOT / "reproducibility"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

from mfd_incident_affine_reachability import AffineGeneratorVerifier  # noqa: E402
from mfd_incident_mpc_certification import verify_command_plan  # noqa: E402
from run_mpc_plan_witness import (  # noqa: E402
    RESIDUAL_UNITS_H,
    RESULTS,
    RUN,
    SERVICE_LIMIT,
    START_EPOCH,
)


OUTPUT = RESULTS / "predictive_repair_path_audit.json"


def main():
    archived = json.loads(RUN.read_text())
    event = archived["decisions"][START_EPOCH]
    info = event["information_box"]
    candidate = np.asarray(event["candidate_commands"], dtype=float)
    proof_ref = event["execution_binding"]["proof_reference"]
    retained_artifact = json.loads((SOURCE_ROOT / proof_ref["path"]).read_text())
    backup = np.tile(np.asarray(retained_artifact["commands"][1], dtype=float), (2, 1))
    durations = [Fraction(1, 12), Fraction(7, 12)]

    # Coarse global scan plus a dense local scan around the pilot transition.
    theta_values = sorted(set(
        [round(value, 10) for value in np.linspace(0.0, 1.0, 21)]
        + [0.25, 0.27, 0.275, 0.28, 0.28125, 0.2822265625, 0.285, 0.29, 0.30]
    ))
    rows = []
    for theta in theta_values:
        commands = (1.0 - theta) * candidate + theta * backup
        started = time.perf_counter()
        certificate = verify_command_plan(
            info["center"],
            commands.tolist(),
            durations,
            initial_time_h=Fraction(1, 3),
            amplitude=0.3,
            duration=1.0,
            initial_box=info["half_widths"],
            residual_bound=RESIDUAL_UNITS_H,
            step_seconds=15.0,
            verifier=AffineGeneratorVerifier(),
            service_checks=[dict(time_h=Fraction(1), coordinate=0, upper=SERVICE_LIMIT / 100)],
            retain_steps=False,
        )
        row = {
            "theta": theta,
            "accepted": certificate["accepted"],
            "failure_kinds": [failure["kind"] for failure in certificate["failures"]],
            "proof_id": certificate["proof_id"],
            "wall_seconds": time.perf_counter() - started,
        }
        rows.append(row)
        OUTPUT.write_text(json.dumps({"complete": False, "rows": rows}, indent=2) + "\n")
        print(json.dumps(row), flush=True)

    accepted = [row["theta"] for row in rows if row["accepted"]]
    rejected = [row["theta"] for row in rows if not row["accepted"]]
    sampled_upward_closed = all(
        not (left["accepted"] and not right["accepted"])
        for left, right in zip(rows, rows[1:])
    )
    payload = {
        "complete": True,
        "scope": "global 0.05 grid plus local transition refinement",
        "rows": rows,
        "accepted_count": len(accepted),
        "rejected_count": len(rejected),
        "smallest_sampled_accepted_theta": min(accepted),
        "largest_sampled_rejected_theta": max(rejected),
        "backup_endpoint_accepted": rows[-1]["theta"] == 1.0 and rows[-1]["accepted"],
        "sampled_acceptance_is_upward_closed": sampled_upward_closed,
        "interpretation": (
            "Upward closure on this finite grid is an empirical audit, not a general "
            "monotonicity theorem for nonlinear plan certification."
        ),
        "total_wall_seconds": sum(row["wall_seconds"] for row in rows),
    }
    OUTPUT.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({key: value for key, value in payload.items() if key != "rows"}, indent=2))


if __name__ == "__main__":
    main()
