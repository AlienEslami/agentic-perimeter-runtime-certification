# Mathematical handoff: certification-aware predictive plan repair

## Purpose

This document freezes the current computational evidence and defines the
mathematical work needed to turn the exploratory predictive repair into a
paper-ready component.  It is written as a handoff to a mathematical reviewer
or another agent.  The manuscript itself has not yet been changed.

## Architectural role

The predictive repair planner is a **proposal tool**.  It has no independent
execution authority.  The runtime sequence is

1. an AI-mediated task record defines the current transportation objective and
   outstanding obligations;
2. an economic MPC tool returns a finite command plan;
3. the existing reachability certifier tests that exact plan;
4. after rejection, the repair tool searches between the rejected plan and the
   currently verified backup;
5. every repair candidate receives a fresh certificate from the inherited
   information set and absolute clock; and
6. the authority executes the original plan, a certified repair, or the
   verified backup.

The certifier remains the final authority.  This separation allows the repair
algorithm to be changed without changing the meaning of a successful
certificate.

## Mathematical object to formalize

At decision time `t`, let

- `I_t = (X_t, W_t, O_t, t)` be the inherited information set, disturbance
  contract, outstanding timed obligations, and absolute time;
- `P^0` be the newly proposed finite command plan;
- `P^B` be a verified continuation valid for `I_t` through its recorded expiry;
- `C_t(P; I_t)` be the sound plan-certificate predicate; and
- `Theta = {theta_0, ..., theta_M}` be a finite ordered search grid satisfying
  `0 = theta_0 < ... < theta_M = 1`.

The current repair family is the componentwise plan homotopy

```text
P(theta) = (1-theta) P^0 + theta P^B,   theta in [0,1].
```

On the finite grid, the implemented decision target is

```text
theta* = min {theta in Theta : C_t(P(theta); I_t) = 1}.
```

If computation ends before a repair is selected, the authority retains
`P^B`.  Exact execution binding is applied to whichever certified plan is
installed.

## Theorem package requested

### T1. Finite-grid repair availability

Assume that:

1. `P^B` is certified for the current inherited information set and obligations;
2. `1` belongs to `Theta`; and
3. every grid evaluation terminates with a pass or fail verdict.

Then the feasible grid set is nonempty because `P(1)=P^B`.  Ordered exhaustive
search terminates in at most `M+1` certificate calls and returns either a
certified repair or the certified backup.

### T2. Sound execution after repair

Assume certificate soundness and exact execution binding.  If the repair
algorithm returns `theta*` only after `C_t(P(theta*);I_t)=1`, then every
trajectory covered by `I_t` satisfies the physical and scheduled-service rows
recorded in that certificate over its validity interval.

This result should explicitly state that the repair generator does not supply
the proof; the existing certifier supplies it.

### T3. Grid-relative minimum intervention

For an ordered grid and the intervention score `d(P(theta),P^0)=theta d(P^B,P^0)`,
the first certified grid point minimizes intervention over the **certified grid
points**.  No monotonicity of certification between adjacent grid points is
needed if every earlier point has actually been tested.

### T4. Timeout-safe execution

If repair computation is interrupted or returns no result before the decision
deadline, retaining the still-valid `P^B` preserves the guarantees of its
execution binding through its original expiry.  Repair computation must not
extend that expiry.

### T5. Recursive availability beyond the current expiry

Separate finite-horizon availability from indefinite availability.  A general
recursive result requires a terminal safe set and terminal policy, or an
equivalent recursively feasible backup synthesis condition.  A suitable
statement is:

- every installed plan reaches a terminal set before expiry;
- the terminal set admits a certified continuation satisfying the remaining
  obligations; and
- that continuation is installed or extended before the active proof expires.

Under these conditions, induction over plan expiries establishes continued
availability.  Without a terminal condition, the proven claim ends at the
recorded backup expiry.

### Optional T6. Performance/intervention bound

If the closed-loop mission cost is Lipschitz with respect to the plan under a
declared norm, derive a bound of the form

```text
|J(P(theta*)) - J(P^0)| <= L_J theta* ||P^B-P^0||.
```

The assumptions needed to make `L_J` finite should be stated for the queue-aware
MFD flow and the finite horizon.  This theorem is useful but is not required for
the basic repair-soundness claim.

## Important mathematical caution

The pilot used bisection.  Bisection requires an upward-closed certification
set along the repair path, or another proved monotonic predicate.  Nonlinear MFD
dynamics do not provide this property automatically.  The numerical path audit
is upward closed on the tested grid, but that is empirical evidence for this
scenario.  The paper-ready algorithm should use ordered exhaustive grid search
unless an explicit monotonicity theorem is established.

Convex input and directional-command constraints ensure that the interpolated
commands remain in those convex command sets.  State, queue, reachability and
deadline feasibility still require the plan certificate.

## Frozen experiment

### Plant and contract

- Seven-state, queue-aware, two-region MFD.
- State order: `(n1,n2,n11,n22,n10,n20,q)` in scaled units of 100 vehicles.
- Exterior storage limit: 2,000 vehicles.
- Decision time: 20 minutes; plan expiry and service deadline: 60 minutes.
- Service row: Region-1 accumulation at 60 minutes no greater than 2,850 vehicles.
- Current physical information half-widths: 25 vehicles in each of the first
  six coordinates and 10 vehicles in the exterior queue.
- Residual-arrival contract: plus or minus 300 vehicles/hour.
- Plan blocks: 5 minutes followed by 35 minutes.
- TTS row: integral of `100 (n1+n2+q)`.
- Regional-priority diagnostic: integral of `100 (n1+4 n2+q)`; lower is better.

### Plans

Rejected MPC plan:

```text
[(1.000000, 1.000000, 0.753452, 1.000000),
 (0.397291, 1.000000, 0.382851, 1.000000)]
```

Verified backup:

```text
[(1.000000, 1.000000, 0.667016, 1.000000),
 (1.000000, 1.000000, 0.667016, 1.000000)]
```

Selected repair:

```text
[(1.000000, 1.000000, 0.729057, 1.000000),
 (0.567392, 1.000000, 0.463050, 1.000000)]
```

The selected interpolation is `theta=0.2822265625`.  Its relative plan
`L2` change from the MPC proposal is `0.07825637` (7.83%).

## Single within-contract witness

| Policy | TTS (veh-h) | Queue (veh-h) | Peak queue (veh) | Region-1 at deadline (veh) | Priority cost | Storage | Deadline |
|---|---:|---:|---:|---:|---:|:---:|:---:|
| Rejected economic MPC | 3302.41 | 686.45 | 2180.04 | 2853.08 | 6334.73 | fail | fail |
| Physical CBF-QP | 3297.61 | 659.77 | 1843.78 | 2918.35 | 6382.59 | pass | fail |
| Certified repair | 3076.53 | 522.71 | 1618.65 | 2260.32 | 6447.19 | pass | pass |
| Verified backup | 2698.68 | 110.70 | 197.98 | 1727.56 | 6820.46 | pass | pass |

Interpretation: the physical CBF-QP enforces the storage row but does not satisfy
the scheduled service row.  The certified repair satisfies both and preserves
more of the requested Region-2 priority than the backup.  The backup has lower
TTS, so the repair realizes a service/priority trade-off rather than a universal
cost improvement.

## Information-box and disturbance ensemble

The repaired, rejected and backup plans were evaluated at every corner of the
seven-dimensional information box (`2^7=128`) under five deterministic
within-contract residual profiles: zero, constant high, constant low,
alternating every five minutes, and a ten-minute sinusoid.  This gives 640
realizations per policy.

| Result | Rejected MPC | Certified repair | Verified backup |
|---|---:|---:|---:|
| Storage passes | 448/640 | 640/640 | 640/640 |
| Service passes | 298/640 | 640/640 | 640/640 |
| Median TTS (veh-h) | 3240.81 | 3014.63 | 2649.57 |
| Median priority cost | 6262.82 | 6374.38 | 6713.41 |

Across the ensemble, the repair preserves 72.08%--76.99% of the MPC priority
benefit relative to the backup; the median is 75.13%.  Its priority cost is
about 5.05% lower than the backup at the median.  Its TTS premium over the
backup is 13.21%--14.21%; the median is 13.79%.

These simulations measure realized performance.  The interval certificate,
not the 640 sampled trajectories, is the source of the robust physical and
service guarantee.

## Repair-path audit

- 28 points were certified: a global grid with spacing 0.05 plus local points
  around the transition.
- Largest rejected sampled value: `theta=0.28125`.
- Smallest accepted sampled value: `theta=0.2822265625`.
- All subsequently tested values through `theta=1` passed.
- The backup endpoint passed a fresh certificate from the current information
  set.
- The sampled accepted set was upward closed.
- Total audit time: 240.05 seconds; mean 8.57 seconds per certificate call.

The observed transition changes from a continuous physical-constraint failure
near the MPC plan to a scheduled-service failure before full certification.
This shows that the repair is resolving both storage and service constraints.

## Claims supported by the present evidence

1. A rejected economic-MPC plan can be repaired toward a verified backup and
   independently certified.
2. In the declared witness, the repair satisfies exterior storage and the
   absolute regional service deadline.
3. The repair preserves a substantial fraction of the agent-requested regional
   priority benefit relative to immediate fallback.
4. A physical CBF-QP can satisfy instantaneous storage safety while missing the
   scheduled service deadline.
5. The backup endpoint makes finite-grid repair availability constructive over
   the active validity interval.

## Claims requiring additional mathematics or experiments

1. Global minimum intervention over all admissible command sequences.
2. General monotonicity of certification in `theta`.
3. Indefinite backup availability without a terminal-set/terminal-policy result.
4. Superiority in TTS: the current backup has lower TTS.
5. Scalability beyond the present two-block, two-region repair path.
6. Field performance under calibrated sensor and MFD parameter errors.

## What comparison with the perimeter-control literature should mean

Reported numbers from different papers should not be compared directly when
their MFDs, demand, queues, information patterns and constraints differ.  A
direct numerical benchmark should reimplement each compatible controller on a
common declared testbed.  The comparison has two layers.

### Guarantee comparison

For every method, tabulate whether it establishes:

- regulation or asymptotic stability;
- robust physical-state and command constraints;
- finite exterior storage;
- an absolute service deadline;
- admissibility of an agent-requested replacement;
- a verified continuation after rejection; and
- a guarantee under the declared uncertainty set.

### Common-plant numerical comparison

Use the same queue-aware MFD, initial information set, disturbance profiles,
request stream, physical rows, service deadline and mission horizon.  Report:

- TTS and completed trips;
- queue vehicle-hours and maximum queue;
- regional-priority or service cost;
- physical and deadline violations;
- proposal acceptance, repair and fallback frequencies;
- command intervention norm; and
- online computation time.

The principal direct comparisons are:

1. **Economic two-region MPC** following Geroliminis, Haddad and Ramezani
   (2013): performance-oriented proposer and unfiltered execution baseline.
2. **Robust CLF perimeter control** following Zhong et al. (2018): closest
   robust formal two-region Part-B controller.
3. **Queue-aware robust sliding-mode control** following Li, Yildirimoglu and
   Ramezani (2021): optional queue-robust controller if its model can be
   faithfully adapted to the common plant.
4. **Physical CBF-QP**: a mechanism ablation distinguishing instantaneous
   physical safety from scheduled service certification.
5. **Certified accept/retain and certified repair**: the two execution-authority
   policies proposed here.

Haddad (2017) should be used to ground boundary-queue modeling.  Learned and
adaptive perimeter controllers should establish that AI or learned proposal
generators are relevant, while direct numerical comparison requires retraining
them on the identical observation, action and demand specification.

## How later papers can benchmark against this work

The repository should expose this experiment as a versioned benchmark rather
than only a table in the paper.  A future paper should be able to supply a plan
or controller adapter and receive the same metrics and verifier verdicts.

Minimum public benchmark package:

1. plant equations, units and MFD coefficients;
2. initial-set and disturbance-contract files;
3. physical, command, queue and service constraints;
4. proposal and obligation traces;
5. reference MPC, CLF, CBF, backup and repair adapters;
6. certificate-verifier entry point;
7. fixed scenario identifiers and deterministic seeds;
8. a common JSON result schema;
9. regression audits and expected hashes; and
10. separate leaderboards for feasible performance and guarantee coverage.

A later method should report both **feasibility/guarantees** and **performance
conditional on feasibility**.  This prevents an infeasible low-cost trajectory
from being ranked above a feasible controller merely because its TTS is lower.
Pareto reporting should retain at least TTS, priority cost, maximum queue,
deadline margin and computation time.

## Reproduction commands

Run from the repository root:

```powershell
python benchmarks/cbf_certified_mpc/run_mpc_plan_witness.py
python benchmarks/cbf_certified_mpc/run_deadline_predictive_filter.py
python benchmarks/cbf_certified_mpc/run_predictive_repair_ensemble.py
python benchmarks/cbf_certified_mpc/run_predictive_repair_path_audit.py
python benchmarks/cbf_certified_mpc/audit_results.py
```

## Authoritative artifacts and hashes

```text
E8AC116431ADD7FCC7B98BEDCD15E8DA4D171FA4146B93312F13662E11AC3F29  run_deadline_predictive_filter.py
42A0F96F43AE6795C4FAB2AD59F8955BD38CE0C56875ED804BBA92E7EEFED5C1  run_predictive_repair_ensemble.py
0D8FF65DE5BA1AB85BC4D92BD04900B79BCA3C606179A42D34B0DCF8B00D188D  run_predictive_repair_path_audit.py
175B94E4A405A50BE60952444045961EADCFDED8C6FD9BC536B3345B80E18838  results/deadline_predictive_filter.json
F0B21C544DBC815102E72704E77A0EB7FC7712C0DD17F33B0BAF180DC4731452  results/predictive_repair_ensemble.json
D0C6167E0FB70D50539CEB4C71EF9500B8A3D7ADDACA44E4E885A5CC1A9562D3  results/predictive_repair_path_audit.json
```

The authoritative source package imported by these scripts is
`output/package/FOUNDATION_MFD_PARTB_REVIEWED_2026-09-11_TASK-NETWORK`.
