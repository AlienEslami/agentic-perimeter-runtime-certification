"""Evaluate the certified predictive repair over an admissible ensemble.

The repair is synthesized and certified by ``run_deadline_predictive_filter``.
This script does not alter that plan.  It executes the rejected MPC plan, the
certified repair, and the retained verified backup from every corner of the
declared information box under five deterministic residual profiles whose
magnitudes remain inside the 300 veh/h contract.

The ensemble is a performance stress test.  Formal safety and service claims
come from the interval certificate, not from the sampled trajectories.
"""
from __future__ import annotations

import itertools
import json
import math
from pathlib import Path

import numpy as np

from run_mpc_plan_witness import (
    END_H,
    RESIDUAL_UNITS_H,
    RUN,
    START_EPOCH,
    START_H,
    SERVICE_LIMIT,
    mpc,
    simulate,
)


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
REPAIR_RECORD = RESULTS / "deadline_predictive_filter.json"
OUTPUT = RESULTS / "predictive_repair_ensemble.json"
PRIORITY_ROW = np.array([1.0, 4.0, 0.0, 0.0, 0.0, 0.0, 1.0])


def residual_profiles():
    bound = RESIDUAL_UNITS_H
    return {
        "zero": lambda _t: 0.0,
        "constant_high": lambda _t: bound,
        "constant_low": lambda _t: -bound,
        "alternating_5min": lambda t: bound if int((t - START_H) * 12) % 2 == 0 else -bound,
        "sinusoidal_10min": lambda t: bound * math.sin(12.0 * math.pi * (t - START_H)),
    }


def command_function(plan):
    plan = np.asarray(plan, dtype=float)
    switch = START_H + 1.0 / 12.0

    def at(t, _x):
        command = plan[0] if t < switch - 1e-12 else plan[1]
        return command, command

    return at


def priority_cost(trajectory):
    times = np.asarray(trajectory["time_h"], dtype=float)
    states = np.asarray(trajectory["state"], dtype=float)
    return float(np.trapezoid(100.0 * states @ PRIORITY_ROW, times))


def describe(values):
    data = np.asarray(values, dtype=float)
    return {
        "minimum": float(np.min(data)),
        "median": float(np.median(data)),
        "maximum": float(np.max(data)),
    }


def main():
    archived = json.loads(RUN.read_text())
    event = archived["decisions"][START_EPOCH]
    info = event["information_box"]
    center = np.asarray(info["center"], dtype=float)
    widths = np.asarray(info["half_widths"], dtype=float)
    repair_record = json.loads(REPAIR_RECORD.read_text())

    plans = {
        "rejected_mpc": repair_record["candidate_commands"],
        "certified_repair": repair_record["selected_commands"],
        "verified_backup": repair_record["backup_commands"],
    }
    command_functions = {name: command_function(plan) for name, plan in plans.items()}
    profiles = residual_profiles()
    records = []

    for signs in itertools.product((-1.0, 1.0), repeat=center.size):
        x0 = center + np.asarray(signs) * widths
        corner_id = "".join("+" if value > 0 else "-" for value in signs)
        for profile_name, residual in profiles.items():
            arrival = lambda t, residual=residual: mpc.arrival(t) + residual(t)
            for policy, command_at in command_functions.items():
                run = simulate(x0, command_at, arrival, policy)
                metrics = dict(run["metrics"])
                metrics["region2_priority_cost"] = priority_cost(run["trajectory"])
                records.append({
                    "corner": corner_id,
                    "residual_profile": profile_name,
                    "policy": policy,
                    "metrics": metrics,
                })

    summaries = {}
    for policy in plans:
        rows = [row["metrics"] for row in records if row["policy"] == policy]
        summaries[policy] = {
            "runs": len(rows),
            "storage_passes": sum(row["storage_safe"] for row in rows),
            "service_passes": sum(row["service_pass"] for row in rows),
            "suffix_tts_veh_h": describe([row["suffix_tts_veh_h"] for row in rows]),
            "queue_veh_h": describe([row["suffix_queue_veh_h"] for row in rows]),
            "maximum_queue_vehicles": describe([row["max_queue_vehicles"] for row in rows]),
            "deadline_region1_vehicles": describe([row["deadline_region1_vehicles"] for row in rows]),
            "region2_priority_cost": describe([row["region2_priority_cost"] for row in rows]),
        }

    grouped = {}
    for row in records:
        key = (row["corner"], row["residual_profile"])
        grouped.setdefault(key, {})[row["policy"]] = row["metrics"]

    priority_fraction = []
    tts_premium = []
    for group in grouped.values():
        nominal = group["rejected_mpc"]["region2_priority_cost"]
        repair = group["certified_repair"]["region2_priority_cost"]
        backup = group["verified_backup"]["region2_priority_cost"]
        denominator = backup - nominal
        if denominator > 1e-9:
            priority_fraction.append((backup - repair) / denominator)
        tts_premium.append(
            100.0
            * (group["certified_repair"]["suffix_tts_veh_h"] - group["verified_backup"]["suffix_tts_veh_h"])
            / group["verified_backup"]["suffix_tts_veh_h"]
        )

    payload = {
        "scope": "128 information-box corners by five within-contract residual profiles",
        "formal_status": (
            "sampled performance ensemble; the separately archived interval certificate "
            "provides physical and scheduled-service soundness"
        ),
        "service_limit_vehicles": SERVICE_LIMIT,
        "residual_bound_veh_h": 100.0 * RESIDUAL_UNITS_H,
        "repair_interpolation": repair_record["selected_theta_upper"],
        "repair_relative_plan_l2_change": repair_record["realization"]["metrics"]["relative_plan_l2_change"],
        "summaries": summaries,
        "repair_priority_benefit_fraction_relative_to_backup": describe(priority_fraction),
        "repair_tts_premium_percent_relative_to_backup": describe(tts_premium),
        "records": records,
    }
    OUTPUT.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({key: value for key, value in payload.items() if key != "records"}, indent=2))


if __name__ == "__main__":
    main()
