# Request to develop the predictive-repair mathematics

Read `PREDICTIVE_REPAIR_MATH_HANDOFF.md` completely, including the frozen
experiment, numerical evidence, claim boundary, and authoritative artifact
hashes.

Develop a rigorous theorem package for certification-aware predictive plan
repair in which an economic-MPC or AI-generated finite plan is tested, a failed
plan is repaired along a declared family toward a currently verified backup,
every selected repair receives a fresh plan certificate, and computation
timeout retains the backup through its original validity interval.

At minimum, provide:

1. precise definitions of the information set, timed obligations, plan,
   certificate predicate, verified backup, repair family, finite search grid,
   execution binding, validity interval, and timeout semantics;
2. a finite-grid repair-availability theorem using the certified backup
   endpoint;
3. a sound-execution theorem for a freshly certified repair;
4. a grid-relative minimum-intervention theorem that does not assume
   certification monotonicity;
5. a timeout-safe retention theorem;
6. a separate recursive-availability theorem stating the terminal-set,
   terminal-policy, obligation-compatibility, and pre-expiry extension
   conditions required beyond the current backup expiry; and
7. if defensible, a finite-horizon Lipschitz performance/intervention bound.

Give complete proofs and audit every quantifier, time interval, expiry
condition, and dependence on the inherited state and disturbance sets.

Do not infer a general monotonicity theorem from the sampled upward-closed
repair path.  The current bisection is exploratory.  Use ordered exhaustive
finite-grid search as the guaranteed algorithm unless you separately derive
checkable sufficient conditions for monotonicity.  Do not claim global minimum
intervention over all command sequences, indefinite fallback availability
without terminal assumptions, or TTS superiority over the backup.

After the general results, instantiate every object for the recorded
seven-state queue-aware MFD experiment and explain exactly which result
certifies the selected `theta=0.2822265625` repair.
