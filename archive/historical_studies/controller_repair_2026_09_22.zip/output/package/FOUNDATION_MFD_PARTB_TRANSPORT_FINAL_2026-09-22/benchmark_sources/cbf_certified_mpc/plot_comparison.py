"""Create the publication-style comparison figure."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
SOURCE = HERE.parents[1] / "output/package/FOUNDATION_MFD_PARTB_REVIEWED_2026-09-11_TASK-NETWORK/reproducibility/results/task_state_runtime_v2"


def load_archived(name):
    return json.loads((SOURCE / name / "result.json").read_text())


def main():
    unfiltered = load_archived("command_pressure_nominal")
    certified = load_archived("command_pressure_certified")
    cbf = json.loads((RESULTS / "cbf_run.json").read_text())
    cases = [
        ("Unfiltered proposals", unfiltered["trajectory"], "#b4473d", "--"),
        ("CBF-QP", cbf["trajectory"], "#d58b22", "-."),
        ("Plan certificate + retention", certified["trajectory"], "#1261a0", "-"),
    ]
    fig, axes = plt.subplots(2, 1, figsize=(7.1, 5.2), sharex=True, constrained_layout=True)
    for label, trajectory, color, style in cases:
        t = 60 * np.asarray(trajectory["time_h"])
        x = np.asarray(trajectory["state"])
        axes[0].plot(t, 100 * x[:, 6], style, color=color, lw=1.8, label=label)
        axes[1].plot(t, 100 * x[:, 0], style, color=color, lw=1.8, label=label)
    axes[0].axhline(2000, color="black", lw=1.0, ls=":", label="Exterior storage limit")
    axes[1].axhline(2850, color="black", lw=1.0, ls=":", label="60-min service limit")
    for minute in (20, 25, 30, 35):
        for ax in axes:
            ax.axvline(minute, color="#777777", lw=0.55, alpha=0.5)
    axes[0].set_ylabel("Exterior queue (veh)")
    axes[1].set_ylabel("Region 1 accumulation (veh)")
    axes[1].set_xlabel("Time (min)")
    axes[0].set_ylim(bottom=0)
    axes[1].set_xlim(0, 60)
    axes[0].legend(frameon=False, fontsize=8, ncol=2)
    axes[1].legend(frameon=False, fontsize=8, ncol=2)
    fig.suptitle("Unsafe replacement proposals: filtering versus plan certification", fontsize=11)
    fig.savefig(RESULTS / "unsafe_mpc_cbf_certified_comparison.pdf")
    fig.savefig(RESULTS / "unsafe_mpc_cbf_certified_comparison.png", dpi=220)


if __name__ == "__main__":
    main()
