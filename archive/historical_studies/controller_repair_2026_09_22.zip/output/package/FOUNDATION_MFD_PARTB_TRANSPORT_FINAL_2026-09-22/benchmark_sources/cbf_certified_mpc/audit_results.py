"""Independent numerical and bookkeeping checks for the comparison artifacts."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
ROOT = HERE.parents[1]
SOURCE = ROOT / "output/package/FOUNDATION_MFD_PARTB_REVIEWED_2026-09-11_TASK-NETWORK/reproducibility"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

import mfd_incident_model as plant  # noqa: E402
import mfd_incident_mpc as mpc  # noqa: E402


def main():
    comparison = json.loads((RESULTS / "comparison.json").read_text())
    cbf = json.loads((RESULTS / "cbf_run.json").read_text())
    rows = {row["policy"]: row for row in comparison["policies"]}
    assert rows["unfiltered_mpc_proposals"]["storage_safe"] is False
    assert rows["cbf_qp_filtered_mpc"]["storage_safe"] is True
    assert rows["plan_certifier_with_suffix_retention"]["storage_safe"] is True
    assert all(row["service_pass"] for row in rows.values())

    states = np.asarray(cbf["trajectory"]["state"])
    nominal = np.asarray(cbf["trajectory"]["nominal_command"])
    executed = np.asarray(cbf["trajectory"]["executed_command"])
    assert states.shape == (361, 7)
    assert nominal.shape == executed.shape == (360, 4)
    assert np.max(states[:, 6]) * 100 <= 2000.0 + 1e-6
    assert np.min(states) >= -1e-8
    assert np.min(executed) >= -1e-8 and np.max(executed) <= 1.0 + 1e-8
    assert np.max(np.abs(executed[:, 1] - executed[:, 0])) <= 0.75 + 1e-8
    assert np.max(np.abs(executed[:, 3] - executed[:, 2])) <= 0.75 + 1e-8
    corrections = np.max(np.abs(executed - nominal), axis=1)
    assert int(np.sum(corrections > 1e-7)) == cbf["metrics"]["filter_intervention_steps"]
    assert abs(float(np.max(corrections)) - cbf["metrics"]["maximum_command_correction"]) <= 1e-10
    # Recompute the robust continuous-time barrier residual at every filter
    # call.  The queue margin loses 0.6 units/h under the declared residual.
    barrier_minimum = np.inf
    for index, u in enumerate(executed):
        x = states[index]
        t = index * mpc.EXECUTION_STEP
        h = mpc.STATE_A @ x + mpc.STATE_B
        residual = mpc.STATE_A @ plant.field(x, u, mpc.arrival(t)) + 6.0 * h
        residual[-1] -= 0.6
        barrier_minimum = min(barrier_minimum, float(np.min(residual)))
    assert barrier_minimum >= -2e-7

    sensitivity = json.loads((RESULTS / "cbf_gain_sensitivity.json").read_text())
    assert [row["alpha_per_hour"] for row in sensitivity["rows"]] == [3.0, 6.0, 12.0]
    assert all(row["storage_safe"] and row["service_pass"] for row in sensitivity["rows"])
    witness = json.loads((RESULTS / "economic_mpc_plan_witness.json").read_text())
    witness_rows = {row["policy"]: row["metrics"] for row in witness["policies"]}
    assert witness["scenario"]["arrival_residual_veh_h"] <= witness["scenario"]["contract_arrival_residual_bound_veh_h"]
    assert witness_rows["unfiltered_economic_mpc_plan"]["storage_safe"] is False
    assert witness_rows["unfiltered_economic_mpc_plan"]["service_pass"] is False
    assert witness_rows["physical_cbf_qp"]["storage_safe"] is True
    assert witness_rows["physical_cbf_qp"]["service_pass"] is False
    assert witness_rows["plan_certificate_with_retained_verified_suffix"]["storage_safe"] is True
    assert witness_rows["plan_certificate_with_retained_verified_suffix"]["service_pass"] is True
    predictive = json.loads((RESULTS / "deadline_predictive_filter.json").read_text())
    pm = predictive["realization"]["metrics"]
    assert predictive["selected_theta_upper"] > predictive["rejected_theta_lower"]
    assert predictive["theta_resolution"] <= 1.0 / 1024 + 1e-12
    assert pm["storage_safe"] is True and pm["service_pass"] is True
    selected_calls = [row for row in predictive["certificate_calls"]
                      if row["accepted"] and row["theta"] == predictive["selected_theta_upper"]]
    assert len(selected_calls) == 1
    report = {
        "passed": True,
        "checks": [
            "unfiltered storage violation reproduced",
            "CBF and plan-certified storage safety reproduced",
            "all three deadline outcomes checked",
            "CBF trajectory dimensions and state nonnegativity checked",
            "CBF input box and directional constraints checked",
            "intervention accounting recomputed",
            "robust continuous-time CBF inequalities recomputed at all 360 filter calls",
            "three-gain sensitivity checked",
            "within-contract economic-MPC physical and service witness checked",
            "deadline-aware backup-interpolation filter certificate and realization checked",
        ],
    }
    report["minimum_recomputed_cbf_residual"] = barrier_minimum
    (RESULTS / "audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
