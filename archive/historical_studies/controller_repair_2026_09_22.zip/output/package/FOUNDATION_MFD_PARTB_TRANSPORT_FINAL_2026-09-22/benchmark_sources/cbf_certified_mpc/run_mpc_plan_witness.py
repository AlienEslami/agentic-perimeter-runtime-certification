"""Execute a rejected economic-MPC plan under an admissible witness.

At minute 20 in the archived adverse25 run, the online economic MPC submits a
two-block plan.  The horizon certificate rejects it.  This script executes the
submitted plan over its stated remaining horizon using a realization inside
the certified information/disturbance contract, and compares it with:

* a branch-exact physical CBF-QP applied to the same MPC plan; and
* the previously verified suffix retained by the runtime authority.

The witness uses the information-box center with its exterior queue at the
declared upper endpoint and a constant +300 veh/h arrival residual.  Both lie
inside the archived contract.  No optimization or witness search occurs here.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE_ROOT = ROOT / "output/package/FOUNDATION_MFD_PARTB_REVIEWED_2026-09-11_TASK-NETWORK"
SOURCE = SOURCE_ROOT / "reproducibility"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

import mfd_incident_model as plant  # noqa: E402
import mfd_incident_mpc as mpc  # noqa: E402
from run_comparison import RESULTS, cbf_filter  # noqa: E402


RUN = SOURCE / "results/sor/adverse25_affine_v3/run.json"
START_EPOCH = 4
START_H = 1.0 / 3.0
END_H = 1.0
SERVICE_LIMIT = 2850.0
RESIDUAL_UNITS_H = 3.0


def simulate(x0, command_at, actual_arrival, label):
    x = x0.copy()
    states = [x.tolist()]
    times = [START_H]
    commands = []
    tts = queue_hours = departures = 0.0
    max_queue = x[6]
    min_margin = np.inf
    first_overflow = None
    interventions = 0
    maximum_correction = 0.0
    for step in range(round((END_H - START_H) / mpc.EXECUTION_STEP)):
        t = START_H + step * mpc.EXECUTION_STEP
        nominal, executed = command_at(t, x)
        correction = float(np.max(np.abs(executed - nominal)))
        interventions += int(correction > 1e-7)
        maximum_correction = max(maximum_correction, correction)
        new = plant.rk4(x, lambda _x, u=executed: u, t, mpc.EXECUTION_STEP, actual_arrival)
        min_margin = min(
            min_margin,
            float(np.min(plant.margins(x, executed))),
            float(np.min(plant.margins(new, executed))),
        )
        max_queue = max(max_queue, new[6])
        if first_overflow is None and new[6] > plant.QUEUE_LIMIT:
            first_overflow = t + mpc.EXECUTION_STEP
        h = mpc.EXECUTION_STEP
        both = x + new
        tts += h / 2 * 100 * (mpc.COST_ROW @ both)
        queue_hours += h / 2 * 100 * both[6]
        departures += h / 2 * 100 * (
            plant.departure_rate(x, executed) + plant.departure_rate(new, executed)
        )
        x = new
        times.append(t + h)
        states.append(x.tolist())
        commands.append(executed.tolist())
    return {
        "policy": label,
        "metrics": {
            "suffix_tts_veh_h": tts,
            "suffix_queue_veh_h": queue_hours,
            "suffix_departures_vehicles": departures,
            "max_queue_vehicles": 100 * max_queue,
            "storage_safe": bool(max_queue <= plant.QUEUE_LIMIT + 1e-8),
            "first_storage_overflow_minutes": None if first_overflow is None else 60 * first_overflow,
            "minimum_sampled_physical_margin": min_margin,
            "deadline_region1_vehicles": 100 * x[0],
            "service_limit_vehicles": SERVICE_LIMIT,
            "service_pass": bool(100 * x[0] <= SERVICE_LIMIT + 1e-8),
            "service_margin_vehicles": SERVICE_LIMIT - 100 * x[0],
            "intervention_steps": interventions,
            "maximum_command_correction": maximum_correction,
        },
        "trajectory": {"time_h": times, "state": states, "command": commands},
    }


def main():
    archived = json.loads(RUN.read_text())
    event = archived["decisions"][START_EPOCH]
    contract = archived["current_contract"]
    info = event["information_box"]
    x0 = np.asarray(info["center"], dtype=float)
    x0[6] += float(info["half_widths"][6])
    assert abs(x0[6] - (info["center"][6] + info["half_widths"][6])) < 1e-12
    candidate = np.asarray(event["candidate_commands"], dtype=float)
    candidate_switch = START_H + 1.0 / 12.0

    proof_ref = event["execution_binding"]["proof_reference"]
    proof_path = SOURCE_ROOT / proof_ref["path"]
    retained_artifact = json.loads(proof_path.read_text())
    assert retained_artifact["certificate"]["accepted"]
    retained = np.asarray(retained_artifact["commands"][1], dtype=float)

    actual_arrival = lambda t: mpc.arrival(t) + RESIDUAL_UNITS_H

    def nominal_command(t):
        return candidate[0] if t < candidate_switch - 1e-12 else candidate[1]

    unfiltered = simulate(
        x0,
        lambda t, _x: (nominal_command(t), nominal_command(t)),
        actual_arrival,
        "unfiltered_economic_mpc_plan",
    )

    def cbf_command(t, x):
        nominal = nominal_command(t)
        executed = cbf_filter(
            x,
            nominal,
            mpc.arrival(t),
            alpha=6.0,
            arrival_residual=RESIDUAL_UNITS_H,
        )[2]
        return nominal, executed

    cbf = simulate(x0, cbf_command, actual_arrival, "physical_cbf_qp")
    certified = simulate(
        x0,
        lambda t, _x: (nominal_command(t), retained),
        actual_arrival,
        "plan_certificate_with_retained_verified_suffix",
    )
    payload = {
        "scenario": {
            "source_run": RUN.relative_to(ROOT).as_posix(),
            "source_epoch": START_EPOCH,
            "start_minutes": 60 * START_H,
            "end_minutes": 60 * END_H,
            "proposal_kind": "economic MPC two-block plan",
            "proposal_commands": candidate.tolist(),
            "proposal_durations_minutes": [5, 35],
            "archived_rejection_reason": event["failure_reason"],
            "initial_state_selection": "information-box center with exterior queue at upper endpoint",
            "initial_state": x0.tolist(),
            "arrival_residual_veh_h": 100 * RESIDUAL_UNITS_H,
            "contract_arrival_residual_bound_veh_h": contract["residual_bound"] * 100,
            "service_limit_vehicles": SERVICE_LIMIT,
            "retained_proof_reference": proof_ref,
            "retained_command": retained.tolist(),
        },
        "policies": [unfiltered, cbf, certified],
        "interpretation": (
            "This is a within-contract execution witness for the submitted MPC plan. "
            "The CBF baseline enforces instantaneous physical rows; the plan certificate "
            "also checks the scheduled service row over the submitted horizon."
        ),
    }
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / "economic_mpc_plan_witness.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"scenario": payload["scenario"], "policies": [
        {"policy": row["policy"], **row["metrics"]} for row in payload["policies"]
    ]}, indent=2))


if __name__ == "__main__":
    main()
