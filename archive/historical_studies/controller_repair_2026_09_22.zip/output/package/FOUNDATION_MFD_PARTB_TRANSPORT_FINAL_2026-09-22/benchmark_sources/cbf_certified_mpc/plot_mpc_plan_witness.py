"""Plot the within-contract economic-MPC plan witness."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"


def main():
    data = json.loads((RESULTS / "economic_mpc_plan_witness.json").read_text())
    style = {
        "unfiltered_economic_mpc_plan": ("Unfiltered economic MPC plan", "#b4473d", "--"),
        "physical_cbf_qp": ("Physical CBF-QP", "#d58b22", "-."),
        "plan_certificate_with_retained_verified_suffix": ("Plan certificate + retained suffix", "#1261a0", "-"),
    }
    fig, axes = plt.subplots(2, 1, figsize=(7.6, 5.5), sharex=True)
    for row in data["policies"]:
        label, color, line = style[row["policy"]]
        t = 60 * np.asarray(row["trajectory"]["time_h"])
        x = np.asarray(row["trajectory"]["state"])
        axes[0].plot(t, 100 * x[:, 6], line, color=color, lw=1.8, label=label)
        axes[1].plot(t, 100 * x[:, 0], line, color=color, lw=1.8, label=label)
    axes[0].axhline(2000, color="black", lw=1.0, ls=":", label="Exterior storage limit")
    axes[1].axhline(2850, color="black", lw=1.0, ls=":", label="60-min service limit")
    axes[0].set_ylabel("Exterior queue (veh)", fontsize=9)
    axes[1].set_ylabel("Region 1 accumulation (veh)", fontsize=9)
    axes[1].set_xlabel("Mission time (min)", fontsize=9)
    axes[0].set_xlim(20, 60)
    axes[0].set_ylim(bottom=0)
    axes[0].legend(frameon=False, fontsize=7.2, ncol=2, loc="upper left")
    axes[1].legend(frameon=False, fontsize=7.2, ncol=2, loc="upper left")
    fig.suptitle("Within-contract witness for a submitted economic-MPC plan", fontsize=10.5, y=.975)
    fig.subplots_adjust(left=.13, right=.985, bottom=.10, top=.91, hspace=.12)
    fig.savefig(RESULTS / "economic_mpc_plan_witness.pdf")
    fig.savefig(RESULTS / "economic_mpc_plan_witness.png", dpi=220)


if __name__ == "__main__":
    main()
