"""Exploratory deadline-aware predictive filter on the MFD witness.

The filter searches the line segment from the rejected economic-MPC plan to
the already verified backup plan.  It returns the smallest interpolation that
passes the same interval reachability certificate for physical constraints and
the absolute n1 deadline.  This is a backup-interpolation predictive filter,
not a claim of globally minimum intervention over all command sequences.
"""
from __future__ import annotations

from fractions import Fraction
import json
import sys
import time
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE_ROOT = ROOT / "output/package/FOUNDATION_MFD_PARTB_REVIEWED_2026-09-11_TASK-NETWORK"
SOURCE = SOURCE_ROOT / "reproducibility"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

from mfd_incident_affine_reachability import AffineGeneratorVerifier  # noqa: E402
from mfd_incident_mpc_certification import verify_command_plan  # noqa: E402
from run_mpc_plan_witness import (  # noqa: E402
    END_H,
    RESIDUAL_UNITS_H,
    RESULTS,
    RUN,
    SERVICE_LIMIT,
    START_EPOCH,
    START_H,
    mpc,
    simulate,
)


def main():
    archived = json.loads(RUN.read_text())
    event = archived["decisions"][START_EPOCH]
    info = event["information_box"]
    candidate = np.asarray(event["candidate_commands"], dtype=float)
    proof_ref = event["execution_binding"]["proof_reference"]
    retained_artifact = json.loads((SOURCE_ROOT / proof_ref["path"]).read_text())
    backup = np.tile(np.asarray(retained_artifact["commands"][1], dtype=float), (2, 1))
    durations = [Fraction(1, 12), Fraction(7, 12)]
    calls = []

    def commands(theta):
        return (1.0 - theta) * candidate + theta * backup

    def certify(theta):
        plan = commands(theta)
        started = time.perf_counter()
        certificate = verify_command_plan(
            info["center"],
            plan.tolist(),
            durations,
            initial_time_h=Fraction(1, 3),
            amplitude=0.3,
            duration=1.0,
            initial_box=info["half_widths"],
            residual_bound=RESIDUAL_UNITS_H,
            step_seconds=15.0,
            verifier=AffineGeneratorVerifier(),
            service_checks=[dict(time_h=Fraction(1), coordinate=0, upper=SERVICE_LIMIT / 100)],
            retain_steps=False,
        )
        record = {
            "theta": theta,
            "accepted": certificate["accepted"],
            "failures": certificate["failures"],
            "proof_id": certificate["proof_id"],
            "wall_seconds": time.perf_counter() - started,
            "commands": plan.tolist(),
        }
        calls.append(record)
        print(json.dumps({k: record[k] for k in ("theta", "accepted", "failures", "wall_seconds")}), flush=True)
        return certificate["accepted"]

    # Independently establish the bracket found by the exploratory pilot.
    low, high = 0.25, 0.375
    assert not certify(low)
    assert certify(high)
    for _ in range(7):
        middle = (low + high) / 2
        if certify(middle):
            high = middle
        else:
            low = middle
    selected_theta = high
    selected = commands(selected_theta)
    selected_call = next(row for row in reversed(calls) if row["theta"] == selected_theta and row["accepted"])

    x0 = np.asarray(info["center"], dtype=float)
    x0[6] += float(info["half_widths"][6])
    switch = START_H + 1.0 / 12.0

    def filtered_at(t, _x):
        index = 0 if t < switch - 1e-12 else 1
        return candidate[index], selected[index]

    actual_arrival = lambda t: mpc.arrival(t) + RESIDUAL_UNITS_H
    realization = simulate(x0, filtered_at, actual_arrival, "deadline_aware_predictive_filter")
    trajectory = realization["trajectory"]
    times = np.asarray(trajectory["time_h"])
    states = np.asarray(trajectory["state"])
    region2_row = np.array([1.0, 4.0, 0.0, 0.0, 0.0, 0.0, 1.0])
    priority_cost = float(np.trapezoid(100 * states @ region2_row, times))
    realization["metrics"]["region2_priority_cost"] = priority_cost
    realization["metrics"]["selected_interpolation"] = selected_theta
    realization["metrics"]["relative_plan_l2_change"] = float(
        np.linalg.norm(selected - candidate) / np.linalg.norm(candidate)
    )
    realization["metrics"]["certification_wall_seconds"] = selected_call["wall_seconds"]

    payload = {
        "method": (
            "one-dimensional backup-interpolation predictive filter; smallest certified "
            "theta within the reported bisection tolerance"
        ),
        "scope_guard": "exploratory baseline, not a globally optimal predictive safety-filter solution",
        "candidate_commands": candidate.tolist(),
        "backup_commands": backup.tolist(),
        "selected_commands": selected.tolist(),
        "selected_theta_upper": selected_theta,
        "rejected_theta_lower": low,
        "theta_resolution": high - low,
        "certificate_calls": calls,
        "realization": realization,
    }
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / "deadline_predictive_filter.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({
        "selected_theta_upper": selected_theta,
        "rejected_theta_lower": low,
        "selected_commands": selected.tolist(),
        "realization_metrics": realization["metrics"],
        "total_certificate_seconds": sum(row["wall_seconds"] for row in calls),
    }, indent=2))


if __name__ == "__main__":
    main()
