"""Run and summarize the declared CBF-gain sensitivity."""
from __future__ import annotations

import json
from pathlib import Path

from run_comparison import RESULTS, run_cbf


def main():
    rows = []
    runs = {}
    for alpha in (3.0, 6.0, 12.0):
        result = run_cbf(alpha=alpha, arrival_residual=0.6)
        runs[str(alpha)] = result
        m = result["metrics"]
        rows.append({
            "alpha_per_hour": alpha,
            "tts_veh_h": m["tts_veh_h"],
            "queue_veh_h": m["queue_veh_h"],
            "max_queue_vehicles": m["max_queue_vehicles"],
            "storage_safe": m["max_queue_vehicles"] <= 2000.0 + 1e-6,
            "deadline_vehicles": m["deadline_vehicles"],
            "service_pass": m["service_pass"],
            "intervention_fraction": m["filter_intervention_fraction"],
            "mean_qp_time_ms": m["mean_qp_time_ms"],
        })
    payload = {
        "fixed_parameters": {
            "arrival_residual_veh_h": 60,
            "filter_period_seconds": 10,
            "storage_limit_vehicles": 2000,
        },
        "rows": rows,
        "runs": runs,
    }
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / "cbf_gain_sensitivity.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"fixed_parameters": payload["fixed_parameters"], "rows": rows}, indent=2))


if __name__ == "__main__":
    main()
