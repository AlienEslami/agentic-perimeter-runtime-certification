"""Compare unfiltered, CBF-filtered, and plan-certified execution.

The CBF baseline uses the same seven-state queue-aware MFD and the same
deterministic command-pressure proposer used in the manuscript.  At minutes
20, 25, 30, and 35 the proposer requests u=(0.8, 0.5, 0, 0.75), which closes
the exterior feed gate during the arrival pulse.

The CBF-QP is a sampled implementation of relative-degree-one zeroing barrier
conditions for every affine state constraint in the plant.  The nonsmooth
queue admission min{60 z, 120 u_02} is handled exactly by enumerating its two
affine branches and selecting the feasible minimum-distance solution.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, minimize


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT / "output/package/FOUNDATION_MFD_PARTB_REVIEWED_2026-09-11_TASK-NETWORK/reproducibility"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

import mfd_incident_model as plant  # noqa: E402
import mfd_incident_mpc as mpc  # noqa: E402
from mfd_incident_service_frontier import solve_service  # noqa: E402


PERIOD = 1.0 / 12.0
END = 1.0
PRESSURE = np.array([0.8, 0.5, 0.0, 0.75])
RESULTS = HERE / "results"
ARCHIVED = SOURCE / "results/task_state_runtime_v2"


def _affine_branch(x: np.ndarray, offered: float, branch: str):
    """Return f(u)=constant+matrix@u and the branch inequality C u >= d."""
    supply_ratio = plant.RELEASE_RATE * x[6] / plant.CAPACITY
    if branch == "capacity":
        uref = np.array([0.5, 0.5, min(0.5, max(0.0, 0.5 * supply_ratio)), 0.5])
        # At z=0 the capacity-side tie rule is obtained with u02=0.
        if supply_ratio == 0.0:
            uref[2] = 0.0
        fref, _, fu = mpc.field_jacobians(x, uref, offered)
        cbranch = np.array([0.0, 0.0, -1.0, 0.0])
        dbranch = -supply_ratio
    elif branch == "supply":
        if supply_ratio >= 1.0:
            return None
        uref = np.array([0.5, 0.5, min(1.0, supply_ratio + 0.25), 0.5])
        fref, _, fu = mpc.field_jacobians(x, uref, offered)
        cbranch = np.array([0.0, 0.0, 1.0, 0.0])
        dbranch = supply_ratio
    else:
        raise ValueError(branch)
    constant = fref - fu @ uref
    return constant, fu, cbranch, dbranch


def cbf_filter(
    x: np.ndarray,
    nominal: np.ndarray,
    offered: float,
    *,
    alpha: float = 6.0,
    arrival_residual: float = 0.6,
):
    """Project a command onto the branch-exact CBF admissible set.

    State margins are h=STATE_A*x+STATE_B.  Each branch solves

        min 0.5 ||u-u_nom||^2
        s.t. d/dt h + alpha h >= 0,

    together with the input polytope.  The queue row is tightened by the
    declared 60 veh/h arrival residual (0.6 in the model's 100-vehicle units).
    """
    nominal = np.asarray(nominal, dtype=float)
    state_margin = mpc.STATE_A @ x + mpc.STATE_B
    candidates = []
    for branch in ("capacity", "supply"):
        affine = _affine_branch(x, offered, branch)
        if affine is None:
            continue
        constant, fu, cbranch, dbranch = affine
        c_state = mpc.STATE_A @ fu
        drift = mpc.STATE_A @ constant
        # Only z_dot contains the uncertain offered-arrival residual.  The
        # storage margin is h_q=QUEUE_LIMIT-z, so its worst-case derivative
        # loses arrival_residual.
        robust_adjustment = np.zeros(len(state_margin))
        robust_adjustment[-1] = -arrival_residual
        d_state = -drift - alpha * state_margin - robust_adjustment

        # |u21-u12|<=0.75 and |u20-u02|<=0.75, expressed C u >= d.
        c_input = np.array([
            [-1.0, 1.0, 0.0, 0.0],
            [1.0, -1.0, 0.0, 0.0],
            [0.0, 0.0, -1.0, 1.0],
            [0.0, 0.0, 1.0, -1.0],
        ])
        d_input = np.full(4, -0.75)
        c = np.vstack((c_state, c_input, cbranch))
        d = np.r_[d_state, d_input, dbranch]
        linear = LinearConstraint(c, d, np.full(len(d), np.inf))
        start = np.clip(nominal, 0.0, 1.0)
        result = minimize(
            lambda u: 0.5 * float((u - nominal) @ (u - nominal)),
            start,
            jac=lambda u: u - nominal,
            bounds=Bounds(np.zeros(4), np.ones(4)),
            constraints=[linear],
            method="SLSQP",
            options={"ftol": 1e-12, "maxiter": 100, "disp": False},
        )
        if result.success and np.min(c @ result.x - d) >= -1e-8:
            candidates.append((float(result.fun), branch, result.x, float(np.min(c @ result.x - d))))
    if not candidates:
        raise RuntimeError("CBF-QP infeasible at the sampled state")
    return min(candidates, key=lambda item: item[0])


def run_cbf(alpha: float = 6.0, arrival_residual: float = 0.6):
    commissioning = SOURCE / "results/task_state_development/n3000_3000_q200_network.json"
    initial_commands = np.asarray(json.loads(commissioning.read_text())["commands"])
    library = plant.default_library()
    actual = plant.BASE_STATE.copy()
    nominal_plan = None
    times = [0.0]
    states = [actual.tolist()]
    nominal_commands = []
    filtered_commands = []
    events = []
    totals = np.zeros(4)  # TTS, queue-hours, departures, offered
    interventions = 0
    maximum_correction = 0.0
    qp_seconds = 0.0
    qp_calls = 0
    minimum_margin = np.inf

    for epoch in range(12):
        now = epoch * PERIOD
        if epoch == 0:
            candidate = initial_commands.copy()
            source = "commissioned_initial_plan"
        elif epoch in (4, 5, 6, 7):
            candidate = np.tile(PRESSURE, (2, 1))
            source = "deterministic_zero_admission_pressure"
        else:
            warm = None if nominal_plan is None else np.asarray(nominal_plan[-1])
            selected, report = solve_service(
                actual,
                now,
                library,
                warm,
                mpc.arrival,
                service_target_vehicles=2850.0,
                deadline_h=1.0,
                horizon_h=END - now,
                cost_row=mpc.COST_ROW,
                priority_minutes=None,
            )
            candidate = None if selected is None else selected[1].reshape(2, 4)
            source = "economic_mpc" if candidate is not None else "retained_nominal_suffix"
        if candidate is not None:
            nominal_plan = candidate.tolist()
            nominal = np.asarray(candidate[0])
        elif nominal_plan is not None:
            nominal = np.asarray(nominal_plan[-1])
        else:
            raise RuntimeError("No plan available")

        event = {
            "epoch": epoch,
            "time_minutes": 60.0 * now,
            "proposal_source": source,
            "nominal_command": nominal.tolist(),
            "maximum_filter_correction": 0.0,
            "filtered_steps": 0,
        }
        for step in range(30):
            t = now + step * mpc.EXECUTION_STEP
            tic = time.perf_counter()
            objective, branch, filtered, slack = cbf_filter(
                actual,
                nominal,
                mpc.arrival(t),
                alpha=alpha,
                arrival_residual=arrival_residual,
            )
            qp_seconds += time.perf_counter() - tic
            qp_calls += 1
            correction = float(np.max(np.abs(filtered - nominal)))
            if correction > 1e-7:
                interventions += 1
                event["filtered_steps"] += 1
            maximum_correction = max(maximum_correction, correction)
            event["maximum_filter_correction"] = max(event["maximum_filter_correction"], correction)
            new = plant.rk4(actual, lambda _x, value=filtered: value, t, mpc.EXECUTION_STEP, mpc.arrival)
            minimum_margin = min(
                minimum_margin,
                float(np.min(plant.margins(actual, filtered))),
                float(np.min(plant.margins(new, filtered))),
            )
            h = mpc.EXECUTION_STEP
            both = actual + new
            totals += np.array([
                h / 2 * 100 * (mpc.COST_ROW @ both),
                h / 2 * 100 * both[6],
                h / 2 * 100 * (plant.departure_rate(actual, filtered) + plant.departure_rate(new, filtered)),
                h / 2 * 100 * (2 * sum(plant.INTERNAL_DEMAND) + mpc.arrival(t) + mpc.arrival(t + h)),
            ])
            actual = new
            times.append(t + h)
            states.append(actual.tolist())
            nominal_commands.append(nominal.tolist())
            filtered_commands.append(filtered.tolist())
        event["final_state"] = actual.tolist()
        events.append(event)

    states_array = np.asarray(states)
    return {
        "configuration": {
            "policy": "sampled_branch_exact_cbf_qp",
            "alpha_per_hour": alpha,
            "arrival_residual_veh_h": 100 * arrival_residual,
            "decision_period_minutes": 5,
            "filter_period_seconds": 10,
            "attack_epochs_minutes": [20, 25, 30, 35],
            "attack_command": PRESSURE.tolist(),
        },
        "metrics": {
            "complete": True,
            "tts_veh_h": float(totals[0]),
            "queue_veh_h": float(totals[1]),
            "departures_vehicles": float(totals[2]),
            "offered_vehicles": float(totals[3]),
            "max_queue_vehicles": float(100 * np.max(states_array[:, 6])),
            "deadline_vehicles": float(100 * actual[0]),
            "service_pass": bool(100 * actual[0] <= 2850.0),
            "sampled_minimum_physical_margin": float(minimum_margin),
            "filter_intervention_steps": interventions,
            "filter_intervention_fraction": interventions / qp_calls,
            "maximum_command_correction": maximum_correction,
            "mean_qp_time_ms": 1000 * qp_seconds / qp_calls,
            "maximum_storage_utilization": float(np.max(states_array[:, 6]) / plant.QUEUE_LIMIT),
        },
        "events": events,
        "trajectory": {
            "time_h": times,
            "state": states,
            "nominal_command": nominal_commands,
            "executed_command": filtered_commands,
        },
    }


def archived_case(name: str):
    data = json.loads((ARCHIVED / name / "result.json").read_text())
    return {
        "configuration": data["configuration"],
        "metrics": data["metrics"],
        "events": data["decisions"],
        "trajectory": data["trajectory"],
    }


def compact(policy: str, result: dict):
    m = result["metrics"]
    return {
        "policy": policy,
        "tts_veh_h": m["tts_veh_h"],
        "queue_veh_h": m["queue_veh_h"],
        "max_queue_vehicles": m["max_queue_vehicles"],
        "storage_safe": m["max_queue_vehicles"] <= 100 * plant.QUEUE_LIMIT + 1e-6,
        "minimum_physical_margin": m["sampled_minimum_physical_margin"],
        "deadline_vehicles": m["deadline_vehicles"],
        "service_pass": m["service_pass"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--alpha", type=float, default=6.0)
    parser.add_argument("--arrival-residual", type=float, default=0.6)
    args = parser.parse_args()
    RESULTS.mkdir(parents=True, exist_ok=True)
    unfiltered = archived_case("command_pressure_nominal")
    certified = archived_case("command_pressure_certified")
    cbf = run_cbf(args.alpha, args.arrival_residual)
    comparison = {
        "scenario": "one-hour 30-percent arrival pulse with zero-admission proposals at minutes 20--35",
        "units": "plant states use 100 vehicles and hours; reported traffic metrics use vehicles",
        "policies": [
            compact("unfiltered_mpc_proposals", unfiltered),
            compact("cbf_qp_filtered_mpc", cbf),
            compact("plan_certifier_with_suffix_retention", certified),
        ],
        "cbf_details": cbf["metrics"],
        "interpretation_guard": (
            "The proposer policy and attack schedule are common. Feedback-dependent MPC commands after "
            "trajectory divergence are re-optimized from each policy's inherited state."
        ),
    }
    tag = f"alpha_{args.alpha:g}_residual_{100 * args.arrival_residual:g}vehph".replace(".", "p")
    (RESULTS / f"cbf_run_{tag}.json").write_text(json.dumps(cbf, indent=2) + "\n")
    (RESULTS / f"comparison_{tag}.json").write_text(json.dumps(comparison, indent=2) + "\n")
    if args.alpha == 6.0 and args.arrival_residual == 0.6:
        (RESULTS / "cbf_run.json").write_text(json.dumps(cbf, indent=2) + "\n")
        (RESULTS / "comparison.json").write_text(json.dumps(comparison, indent=2) + "\n")
    print(json.dumps(comparison, indent=2))


if __name__ == "__main__":
    main()
