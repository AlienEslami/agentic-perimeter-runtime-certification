# Unsafe-MPC benchmark: unfiltered, CBF-QP, and plan certification

This benchmark uses the manuscript's seven-state queue-aware two-region MFD.
The proposer requests the command `(0.8, 0.5, 0, 0.75)` at minutes 20, 25,
30, and 35.  Thus the exterior admission gate is closed during the incident
arrival pulse.

Three execution architectures are compared:

1. **Unfiltered proposals:** each proposed replacement is executed.
2. **CBF-QP:** every 10 seconds, a quadratic program minimally modifies the
   current proposed command.  Relative-degree-one barrier inequalities cover
   all affine physical state rows, the input box, and gate-difference limits.
   The nonsmooth queue admission law is represented exactly by enumerating its
   capacity- and supply-limited affine branches.  The queue row includes the
   manuscript's 60 veh/h residual allowance.
3. **Plan certifier:** the paper's horizon-wide reachability certificate either
   installs the whole replacement or retains the previously verified suffix.

The CBF is an independently implemented baseline, not part of the manuscript's
certificate.  Its gain is declared as `alpha=6 h^-1`; sensitivity should be
reported before a manuscript claim is made.

Run:

```powershell
python benchmarks/cbf_certified_mpc/run_comparison.py
```

The declared gain sensitivity and independent artifact audit are run with:

```powershell
python benchmarks/cbf_certified_mpc/run_sensitivity.py
python benchmarks/cbf_certified_mpc/audit_results.py
python benchmarks/cbf_certified_mpc/plot_comparison.py
python benchmarks/cbf_certified_mpc/run_mpc_plan_witness.py
python benchmarks/cbf_certified_mpc/plot_mpc_plan_witness.py
python benchmarks/cbf_certified_mpc/run_deadline_predictive_filter.py
python benchmarks/cbf_certified_mpc/run_predictive_repair_ensemble.py
python benchmarks/cbf_certified_mpc/run_predictive_repair_path_audit.py
```

The primary outputs are `results/cbf_run.json`, `results/comparison.json`,
`results/cbf_gain_sensitivity.json`, `results/audit.json`, and the PDF/PNG
comparison figure.

`economic_mpc_plan_witness.json` is the stronger transportation benchmark.  It
uses the economic-MPC plan archived at minute 20 of `adverse25_affine_v3`, the
information-box upper queue endpoint, and a +300 veh/h residual inside that
run's contract.  It tests the submitted 40-minute plan as a plan, including a
planner-unavailability interpretation in which no later reoptimization repairs
its tail.

`deadline_predictive_filter.json` is an exploratory stronger baseline.  It
interpolates the rejected MPC plan toward the verified backup and uses the
paper's unchanged interval verifier to locate the smallest certifiable point
on that line segment.  It is intentionally labeled as a restricted
backup-interpolation filter rather than a globally optimal predictive safety
filter.

`predictive_repair_ensemble.json` evaluates the selected certified repair at
all 128 corners of the current information box under five deterministic
within-contract residual profiles.  `predictive_repair_path_audit.json` records
a global and locally refined certification scan from the rejected MPC plan to
the verified backup.  The mathematical definitions, exact results, claim
boundary, theorem targets, and literature-benchmark protocol are consolidated
in `PREDICTIVE_REPAIR_MATH_HANDOFF.md`.

The proposer rule and attack schedule are common across policies.  Because MPC
is feedback-dependent, commands after the trajectories diverge are reoptimized
from each policy's inherited state; the comparison therefore evaluates the
same proposer policy rather than claiming an identical open-loop command trace.
