"""Join the matched CLF-extension results to the archived MPC certificate summary."""
from __future__ import annotations

import csv
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLF_PATH = HERE / "results/common_plant_clf_queue_extension.json"
MPC_PATH = (
    HERE.parents[1]
    / "output/package/FOUNDATION_MFD_PARTB_REVIEWED_2026-09-10_ONLINE-STRUCTURE"
    / "reproducibility/results/mfd_incident_mpc_certification_summary_results.json"
)


def key(record):
    return round(float(record["amplitude"]), 8), round(float(record["duration_h"]), 8)


def main():
    clf_payload = json.loads(CLF_PATH.read_text(encoding="utf-8"))
    mpc_payload = json.loads(MPC_PATH.read_text(encoding="utf-8"))
    clf = {key(record): record for record in clf_payload["runs"]}
    mpc = {key(record): record for record in mpc_payload["cases"]}
    if clf.keys() != mpc.keys():
        raise RuntimeError(f"Scenario grids differ: CLF={sorted(clf)} MPC={sorted(mpc)}")
    rows = []
    for scenario in sorted(clf):
        c = clf[scenario]["metrics"]
        m = mpc[scenario]
        row = {
            "amplitude": scenario[0],
            "duration_h": scenario[1],
            "clf_tts_veh_h": c["total_time_spent_veh_h"],
            "nominal_mpc_tts_veh_h": m["nominal_mpc_tts_veh_h"],
            "certified_mpc_tts_veh_h": m["certified_mpc_tts_veh_h"],
            "certified_vs_clf_tts_reduction_percent": 100.0 * (
                c["total_time_spent_veh_h"] - m["certified_mpc_tts_veh_h"]
            ) / c["total_time_spent_veh_h"],
            "clf_deadline_n1_vehicles": c["deadline_n1_vehicles"],
            "certified_mpc_deadline_n1_vehicles": m["deadline_n1_vehicles"],
            "deadline_limit_vehicles": 2850.0,
            "clf_deadline_pass": c["deadline_pass"],
            "certified_mpc_deadline_pass": m["deadline_n1_vehicles"] <= 2850.0,
            "clf_peak_queue_vehicles": c["maximum_queue_vehicles"],
            "certified_mpc_peak_queue_vehicles": m["peak_queue_vehicles"],
            "clf_full_horizon_completed": c["full_horizon_completed"],
            "certified_mpc_complete": m["complete"],
            "nominal_to_certified_tts_change_percent": m["certification_tts_cost_percent"],
            "successful_certificates": m["successful_certificates"],
            "failed_certificates": m["failed_certificates"],
        }
        rows.append(row)
    summary = {
        "scope": "matched seven-state queue-aware incidents",
        "baseline_label": "Zhong-style two-gate almost-smooth CLF plus declared queue/exit LQR extension",
        "interpretation": (
            "The comparison evaluates an operational service task on a common plant. "
            "It does not replace the separate native-model reproduction and does not "
            "claim that the published two-gate CLF violates its own guarantees."
        ),
        "all_clf_runs_physically_completed": all(row["clf_full_horizon_completed"] for row in rows),
        "clf_deadline_passes": sum(row["clf_deadline_pass"] for row in rows),
        "certified_mpc_deadline_passes": sum(row["certified_mpc_deadline_pass"] for row in rows),
        "minimum_tts_reduction_percent": min(row["certified_vs_clf_tts_reduction_percent"] for row in rows),
        "median_tts_reduction_percent": sorted(row["certified_vs_clf_tts_reduction_percent"] for row in rows)[len(rows) // 2 - 1:len(rows) // 2 + 1],
        "maximum_tts_reduction_percent": max(row["certified_vs_clf_tts_reduction_percent"] for row in rows),
        "rows": rows,
    }
    median_pair = summary["median_tts_reduction_percent"]
    summary["median_tts_reduction_percent"] = sum(median_pair) / len(median_pair)
    json_path = HERE / "results/matched_clf_mpc_comparison.json"
    csv_path = HERE / "results/matched_clf_mpc_comparison.csv"
    json_path.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({key: value for key, value in summary.items() if key != "rows"}, indent=2))
    print(json_path)
    print(csv_path)


if __name__ == "__main__":
    main()
