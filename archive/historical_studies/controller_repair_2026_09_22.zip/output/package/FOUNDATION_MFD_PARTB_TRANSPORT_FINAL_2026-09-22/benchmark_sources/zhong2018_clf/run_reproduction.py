"""Reproduce and audit the fixed-demand CLF examples of Zhong et al. (2018)."""
from __future__ import annotations

import json
from pathlib import Path
import numpy as np

from zhong_model import (
    CASE_1,
    CASE_2,
    almost_smooth_gate,
    conservation_rate,
    field,
    totals,
)

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def settling_time(time_s: np.ndarray, trajectory: np.ndarray, target: np.ndarray, band: float) -> float | None:
    errors = np.max(np.abs(trajectory - target), axis=1)
    suffix_max = np.maximum.accumulate(errors[::-1])[::-1]
    indices = np.flatnonzero(suffix_max <= band)
    return None if not len(indices) else float(time_s[indices[0]])


def simulate(
    case,
    lower,
    upper,
    split="published",
    horizon_minutes=150.0,
    integration_step_seconds=0.25,
    output_step_seconds=5.0,
):
    initial = case.initial_state(split)

    def rhs(_time, state):
        gate = almost_smooth_gate(state, case, lower, upper)
        return field(state, gate, case.demand)

    horizon_seconds = 60.0 * horizon_minutes
    nsteps = round(horizon_seconds / integration_step_seconds)
    if abs(nsteps * integration_step_seconds - horizon_seconds) > 1e-10:
        raise ValueError("The integration step must divide the horizon")
    output_stride = round(output_step_seconds / integration_step_seconds)
    if abs(output_stride * integration_step_seconds - output_step_seconds) > 1e-10:
        raise ValueError("The integration step must divide the output step")
    state = initial.copy()
    time_values = [0.0]
    state_values = [state.copy()]
    for k in range(nsteps):
        time = k * integration_step_seconds
        h = integration_step_seconds
        k1 = rhs(time, state)
        k2 = rhs(time + h / 2.0, state + h * k1 / 2.0)
        k3 = rhs(time + h / 2.0, state + h * k2 / 2.0)
        k4 = rhs(time + h, state + h * k3)
        state = state + h * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0
        if (k + 1) % output_stride == 0:
            time_values.append((k + 1) * h)
            state_values.append(state.copy())
    evaluation_time = np.asarray(time_values)
    states = np.asarray(state_values)
    aggregate = np.array([totals(x) for x in states])
    gates = np.array([almost_smooth_gate(x, case, lower, upper) for x in states])
    direct_rate = np.array([np.sum(field(x, u, case.demand)) for x, u in zip(states, gates)])
    balance_rate = np.array([conservation_rate(x, u, case.demand) for x, u in zip(states, gates)])
    return {
        "case": case.name,
        "initial_destination_split": split,
        "gate_bounds": [lower, upper],
        "reported_initial_totals": case.initial_totals.tolist(),
        "constructed_initial_state": initial.tolist(),
        "final_totals": aggregate[-1].tolist(),
        "maximum_total_error_vehicles": float(np.max(np.abs(aggregate - case.target_totals))),
        "final_total_error_inf_vehicles": float(np.max(np.abs(aggregate[-1] - case.target_totals))),
        "settling_time_50veh_seconds": settling_time(evaluation_time, aggregate, case.target_totals, 50.0),
        "settling_time_10veh_seconds": settling_time(evaluation_time, aggregate, case.target_totals, 10.0),
        "minimum_state_vehicles": float(states.min()),
        "minimum_gate": float(gates.min()),
        "maximum_gate": float(gates.max()),
        "maximum_conservation_rate_residual": float(np.max(np.abs(direct_rate - balance_rate))),
        "integration_method": "fixed-step classical RK4",
        "integration_step_seconds": integration_step_seconds,
        "output_step_seconds": output_step_seconds,
        "time_seconds": evaluation_time.tolist(),
        "state": states.tolist(),
        "totals": aggregate.tolist(),
        "gate": gates.tolist(),
    }


def equilibrium_audit(case):
    residual = field(case.reported_equilibrium, case.steady_gate, case.demand)
    return {
        "case": case.name,
        "reported_equilibrium": case.reported_equilibrium.tolist(),
        "reported_steady_gate": case.steady_gate.tolist(),
        "component_residual_veh_per_s": residual.tolist(),
        "residual_inf_veh_per_s": float(np.max(np.abs(residual))),
        "aggregate_residual_inf_veh_per_s": float(np.max(np.abs([residual[0] + residual[1], residual[2] + residual[3]]))),
    }


def main():
    RESULTS.mkdir(exist_ok=True)
    runs = []
    for bounds in ((0.1, 0.9), (0.2, 0.8), (0.4, 0.6)):
        runs.append(simulate(CASE_1, *bounds, split="published"))
    for split in ("equilibrium", "symmetric", "perturbed"):
        runs.append(simulate(CASE_1, 0.1, 0.9, split=split))
    # The second published example used the bang-bang-like controller.  We keep
    # its equilibrium audit here and defer its exact controller reproduction.
    payload = {
        "source": "Zhong et al., Transportation Research Part B 117 (2018), 687-707",
        "scope": "fixed-demand almost-smooth CLF reproduction and initial-split sensitivity",
        "equilibrium_audits": [equilibrium_audit(CASE_1), equilibrium_audit(CASE_2)],
        "runs": runs,
    }
    output = RESULTS / "zhong2018_fixed_demand_reproduction.json"
    output.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"Wrote {output}")
    for run in runs:
        if run["initial_destination_split"] == "published":
            print(
                run["gate_bounds"],
                "settle50_s=", run["settling_time_50veh_seconds"],
                "settle10_s=", run["settling_time_10veh_seconds"],
                "final_inf=", run["final_total_error_inf_vehicles"],
            )


if __name__ == "__main__":
    main()
