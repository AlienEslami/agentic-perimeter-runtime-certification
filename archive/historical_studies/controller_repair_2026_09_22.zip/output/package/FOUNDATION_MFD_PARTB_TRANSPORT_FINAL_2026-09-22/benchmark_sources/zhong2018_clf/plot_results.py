"""Create publication-ready diagnostic and matched-comparison figures."""
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"


def matched_comparison():
    payload = json.loads((RESULTS / "matched_clf_mpc_comparison.json").read_text(encoding="utf-8"))
    rows = payload["rows"]
    labels = [f"{int(100*r['amplitude'])}%/{60*r['duration_h']:.0f} min" for r in rows]
    x = np.arange(len(rows))
    clf_tts = np.array([r["clf_tts_veh_h"] for r in rows])
    mpc_tts = np.array([r["certified_mpc_tts_veh_h"] for r in rows])
    clf_deadline = np.array([r["clf_deadline_n1_vehicles"] for r in rows])
    mpc_deadline = np.array([r["certified_mpc_deadline_n1_vehicles"] for r in rows])
    clf_queue = np.array([r["clf_peak_queue_vehicles"] for r in rows])
    mpc_queue = np.array([r["certified_mpc_peak_queue_vehicles"] for r in rows])

    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
    fig, axes = plt.subplots(3, 1, figsize=(7.25, 7.3), sharex=True, constrained_layout=True)
    width = 0.38
    colors = ("#5B5B5B", "#0072B2")
    axes[0].bar(x - width / 2, clf_tts, width, color=colors[0], label="CLF + queue extension")
    axes[0].bar(x + width / 2, mpc_tts, width, color=colors[1], label="Certified MPC")
    axes[0].set_ylabel("TTS (veh-h)")
    axes[0].legend(frameon=False, ncol=2, loc="upper left")
    axes[0].set_title("Matched queue-aware incident benchmark")

    axes[1].plot(x, clf_deadline, "o-", color=colors[0], label="CLF + queue extension")
    axes[1].plot(x, mpc_deadline, "s-", color=colors[1], label="Certified MPC")
    axes[1].axhline(2850.0, color="#D55E00", linestyle="--", linewidth=1.4, label="service limit")
    axes[1].set_ylabel("Region 1 at 1 h (veh)")
    axes[1].legend(frameon=False, ncol=3, loc="upper left")

    axes[2].plot(x, clf_queue, "o-", color=colors[0], label="CLF + queue extension")
    axes[2].plot(x, mpc_queue, "s-", color=colors[1], label="Certified MPC")
    axes[2].set_ylabel("Peak exterior queue (veh)")
    axes[2].set_xlabel("Incident amplitude / duration")
    axes[2].set_xticks(x, labels, rotation=28, ha="right")
    axes[2].legend(frameon=False, ncol=2, loc="upper left")
    fig.savefig(RESULTS / "matched_clf_mpc_comparison.png", dpi=300)
    plt.close(fig)


def reproduction_diagnostic():
    payload = json.loads((RESULTS / "zhong2018_fixed_demand_reproduction.json").read_text(encoding="utf-8"))
    selected = next(
        run for run in payload["runs"]
        if run["initial_destination_split"] == "published" and run["gate_bounds"] == [0.1, 0.9]
    )
    time_min = np.asarray(selected["time_seconds"]) / 60.0
    totals = np.asarray(selected["totals"])
    gates = np.asarray(selected["gate"])
    fig, axes = plt.subplots(2, 1, figsize=(7.25, 5.1), sharex=True, constrained_layout=True)
    axes[0].plot(time_min, totals[:, 0], color="#0072B2", label=r"$n_1$")
    axes[0].plot(time_min, totals[:, 1], color="#D55E00", label=r"$n_2$")
    axes[0].axhline(3000.0, color="black", linestyle="--", linewidth=1.0, label="target")
    axes[0].set_ylabel("Accumulation (veh)")
    axes[0].set_title("Literal constant-demand four-state reproduction audit")
    axes[0].legend(frameon=False, ncol=3)
    axes[1].plot(time_min, gates[:, 0], color="#0072B2", label=r"$u_1$")
    axes[1].plot(time_min, gates[:, 1], color="#D55E00", label=r"$u_2$")
    axes[1].set_xlabel("Time (min)")
    axes[1].set_ylabel("Gate ratio")
    axes[1].legend(frameon=False, ncol=2)
    fig.savefig(RESULTS / "zhong2018_reproduction_audit.png", dpi=300)
    plt.close(fig)


if __name__ == "__main__":
    matched_comparison()
    reproduction_diagnostic()
    print(RESULTS / "matched_clf_mpc_comparison.png")
    print(RESULTS / "zhong2018_reproduction_audit.png")
