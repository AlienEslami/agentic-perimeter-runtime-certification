# Zhong et al. (2018) CLF benchmark

This directory reproduces the fixed-demand two-region benchmark in
R. X. Zhong et al., *Transportation Research Part B* 117 (2018), 687--707.
It is intentionally isolated from the manuscript's existing numerical package.

The first stage uses the paper's four destination-class states, cubic MFD,
demands, reported equilibria, gate bounds, and almost-smooth feedback law.
The audit reports:

- the residual of the rounded equilibrium printed in the paper;
- state and input feasibility over the simulated trajectory;
- the vehicle-conservation residual;
- total-accumulation settling times; and
- sensitivity to the destination split (the regional totals printed by Zhong
  et al. are supplemented by the OD-specific benchmark initialization
  n11=540, n12=1260, n21=2170, n22=930 vehicles).

Run from this directory with:

```powershell
python run_reproduction.py
python run_common_plant_clf.py
python make_comparison.py
python plot_results.py
python -m unittest test_reproduction.py
python -m unittest test_common_plant.py
```

`run_common_plant_clf.py` evaluates a declared CLF+queue extension on the same
seven-state plant and eight incidents already used by the manuscript's nominal
and certified MPC experiments. `make_comparison.py` joins those fresh runs to
the archived certification summary without recomputing or changing it.

See `BENCHMARK_FINDINGS.md` for the interpretation and claim boundary.  In
particular, the queue-aware comparison is a matched operational benchmark; it
is not presented as a reproduction of the published two-gate CLF controller.
