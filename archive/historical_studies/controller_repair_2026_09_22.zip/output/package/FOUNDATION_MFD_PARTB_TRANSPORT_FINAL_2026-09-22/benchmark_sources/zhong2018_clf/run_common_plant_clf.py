"""Matched queue-aware-plant evaluation of a Zhong-style CLF regulator.

The published controller has two cross-boundary gates and no exterior queue.
For the manuscript's seven-state plant, this script uses its almost-smooth CLF
law for the two cross-boundary gates and the *same fixed region-1-protection
feedback mode* for the exterior admission and exit gates.  The hybrid is
therefore labeled CLF+queue extension rather than a reproduction of Zhong.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
REPRO = HERE.parents[1] / "output/package/FOUNDATION_MFD_PARTB_REVIEWED_2026-09-10_ONLINE-STRUCTURE/reproducibility"
sys.path.insert(0, str(REPRO))

import mfd_incident_model as plant  # noqa: E402
import mfd_incident_mpc as mpc  # noqa: E402


def almost_smooth_correction(alpha: float, beta: np.ndarray) -> np.ndarray:
    b = float(beta @ beta)
    if b <= np.finfo(float).eps:
        return np.zeros_like(beta)
    phi = -(alpha + np.sqrt(alpha * alpha + b * b)) / (
        b * (1.0 + np.sqrt(1.0 + b))
    )
    return phi * beta


class ClfQueueExtension:
    def __init__(self, lower=0.0, upper=1.0):
        self.mode = plant.synthesize(
            "region1_protection", 27.0, 32.0,
            (4.0, 1.0, 0.1, 0.1, 0.1, 0.1, 2.0), 3000.0,
        )
        self.lower = lower
        self.upper = upper

    def command(self, state, offered_arrival):
        state = np.asarray(state)
        reference = self.mode.feedforward.copy()
        # The queue-admission and outside-exit channels are the matched LQR
        # extension; only the two inter-region gates come from the CLF law.
        command = self.mode.command(state)
        error_vehicles = 100.0 * (state[:2] - self.mode.center[:2])
        f_veh_s = (100.0 / 3600.0) * plant.field(state, reference, offered_arrival)[:2]
        n1, n2, n11, n22, n10, n20, _z = state
        n12 = n1 - n11 - n10
        n21 = n2 - n22 - n20
        q12_plus_q10 = plant.original.class_flow(n12 + n10, n1)
        q21 = plant.original.class_flow(n21, n2)
        s = (100.0 / 3600.0) * np.array([
            [-q12_plus_q10, q21],
            [q12_plus_q10, -q21],
        ])
        alpha = float(error_vehicles @ f_veh_s)
        beta = s.T @ error_vehicles
        correction = almost_smooth_correction(alpha, beta)
        low_shift = self.lower - reference[:2]
        high_shift = self.upper - reference[:2]
        command[:2] = reference[:2] + np.clip(correction, low_shift, high_shift)
        # The manuscript plant adds |u21-u12|<=0.75, absent from Zhong's
        # independent box constraints.  Project only when that added row binds.
        difference = command[1] - command[0]
        if abs(difference) > 0.75:
            midpoint = 0.5 * (command[0] + command[1])
            signed_half_width = 0.375 * np.sign(difference)
            command[0] = midpoint - signed_half_width
            command[1] = midpoint + signed_half_width
        return command


def run_case(amplitude, duration, step=1.0 / 360.0, horizon=2.0):
    policy = ClfQueueExtension()
    offered = lambda t: plant.arrival(t, amplitude=amplitude, duration=duration)
    state = plant.BASE_STATE.copy()
    total = queue = departures = offered_integral = 0.0
    minimum_margin = np.inf
    maximum_queue = state[6]
    deadline_n1 = None
    time_values = [0.0]
    state_values = [state.copy()]
    command_values = []
    stopped = None
    for k in range(round(horizon / step)):
        time = k * step
        controller = lambda x, t=time: policy.command(x, offered(t))
        command = controller(state)
        minimum_margin = min(minimum_margin, float(np.min(plant.margins(state, command))))
        if minimum_margin < -1e-6:
            stopped = dict(time_h=time, reason="physical_constraint_violation", margin=minimum_margin)
            break
        new = plant.rk4(state, controller, time, step, offered)
        new_command = policy.command(new, offered(time + step))
        minimum_margin = min(minimum_margin, float(np.min(plant.margins(new, new_command))))
        total += step / 2.0 * 100.0 * (mpc.COST_ROW @ (state + new))
        queue += step / 2.0 * 100.0 * (state[6] + new[6])
        departures += step / 2.0 * 100.0 * (
            plant.departure_rate(state, command) + plant.departure_rate(new, new_command)
        )
        offered_integral += step / 2.0 * 100.0 * (
            2.0 * np.sum(plant.INTERNAL_DEMAND) + offered(time) + offered(time + step)
        )
        state = new
        maximum_queue = max(maximum_queue, state[6])
        command_values.append(command.tolist())
        time_values.append(time + step)
        state_values.append(state.copy())
        if abs(time + step - mpc.DEADLINE) < 1e-10:
            deadline_n1 = 100.0 * float(state[0])
        if minimum_margin < -1e-6:
            stopped = dict(time_h=time + step, reason="physical_constraint_violation", margin=minimum_margin)
            break
    conservation = (
        100.0 * (mpc.COST_ROW @ plant.BASE_STATE)
        + offered_integral
        - 100.0 * (mpc.COST_ROW @ state)
        - departures
    )
    return dict(
        amplitude=amplitude,
        duration_h=duration,
        policy="Zhong almost-smooth inter-region CLF plus matched queue/exit LQR channels",
        metrics=dict(
            total_time_spent_veh_h=total,
            queue_time_veh_h=queue,
            completed_trips_vehicles=departures,
            maximum_queue_vehicles=100.0 * maximum_queue,
            deadline_n1_vehicles=deadline_n1,
            deadline_pass=deadline_n1 is not None and deadline_n1 <= 100.0 * mpc.TARGET_N1,
            minimum_physical_margin=minimum_margin,
            completed_horizon_h=time_values[-1],
            full_horizon_completed=stopped is None and abs(time_values[-1] - horizon) < 1e-10,
            stopped=stopped,
            conservation_residual_vehicles=conservation,
        ),
        trajectory=dict(time_h=time_values, state=np.asarray(state_values).tolist(), command=command_values),
    )


def main():
    cases = ((0.2, 0.5), (0.2, 1.0), (0.3, 0.5), (0.3, 1.0),
             (0.4, 0.5), (0.4, 1.0), (0.25, 0.75), (0.35, 0.75))
    payload = {
        "scope": "matched seven-state plant; CLF cross-gates with declared queue extension",
        "comparability": {
            "same_plant_and_incidents_as_certified_mpc": True,
            "published_Zhong_controller_unchanged": False,
            "reason": "the published two-gate plant has no exterior queue or admission/exit channels",
        },
        "runs": [],
    }
    for amplitude, duration in cases:
        record = run_case(amplitude, duration)
        payload["runs"].append(record)
        print(amplitude, duration, record["metrics"], flush=True)
    output = HERE / "results/common_plant_clf_queue_extension.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
