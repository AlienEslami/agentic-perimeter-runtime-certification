import unittest
import numpy as np

from run_common_plant_clf import ClfQueueExtension, plant, run_case


class CommonPlantClfTests(unittest.TestCase):
    def test_added_directional_constraint_is_enforced(self):
        policy = ClfQueueExtension()
        command = policy.command(plant.BASE_STATE, plant.BASE_ARRIVAL)
        self.assertLessEqual(abs(float(command[1] - command[0])), 0.75 + 1e-12)
        self.assertGreaterEqual(float(np.min(plant.margins(plant.BASE_STATE, command))), -1e-12)

    def test_primary_case_completes_with_small_conservation_residual(self):
        result = run_case(0.3, 1.0)
        metrics = result["metrics"]
        self.assertTrue(metrics["full_horizon_completed"])
        self.assertIsNone(metrics["stopped"])
        self.assertLess(abs(metrics["conservation_residual_vehicles"]), 5.0)
        self.assertGreaterEqual(metrics["minimum_physical_margin"], -1e-9)


if __name__ == "__main__":
    unittest.main()
