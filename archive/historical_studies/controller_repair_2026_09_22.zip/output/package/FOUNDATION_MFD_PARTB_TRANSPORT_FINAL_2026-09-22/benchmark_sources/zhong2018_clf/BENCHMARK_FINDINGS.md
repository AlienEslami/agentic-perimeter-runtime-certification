# Benchmark findings (working record)

## What is directly reproduced

The model audit implements equations (1a)--(1d), the cubic MFD, the demands,
the reported equilibria and the almost-smooth controller in equations
(12)--(15) of Zhong et al. (2018).  The rounded printed equilibria have
component residuals below 0.0003 veh/s.  Gate limits and vehicle conservation
are satisfied numerically.

The paper prints only regional initial totals.  The benchmark lineage supplies
the OD-specific initialization (540, 1260, 2170, 930 vehicles).  With literal
constant demands, the resulting four-state trajectory does not reproduce the
paper's reported six-minute convergence.  It approaches and crosses the
3,000-vehicle target and later moves toward another equal-accumulation state.
This is consistent with the fact that cross-boundary gates redistribute
vehicles but cannot directly control total network accumulation.  Zhong's
state-dependent ``strictly admissible demand'' construction may account for
the difference, but its feedback dependence must be resolved before this
reproduction is suitable as manuscript evidence.

## Matched operational comparison

The operational comparison uses the manuscript's seven-state plant and the
same eight incident scenarios as its nominal and certified MPC runs.  Because
the published CLF plant has no exterior queue, the comparison baseline is
declared as a **CLF+queue extension**: Zhong's almost-smooth law controls the
two cross-boundary gates, while the same fixed region-1-protection feedback
used by the manuscript supplies the exterior admission and exit gates.  The
extra directional gate constraint is enforced by projection.

Across all eight scenarios, the CLF extension remains inside the plant's
physical constraints and completes the two-hour horizon.  It misses the
one-hour regional service limit in all eight cases.  Certified MPC meets the
limit in all eight cases, retains exactly the nominal-MPC TTS in these nominal
realizations, and reduces TTS relative to the CLF extension by the range
reported in `results/matched_clf_mpc_comparison.json`.

## Claim boundary

The supported claim is that the runtime-certified MPC architecture performs
better on the **queue-aware finite-horizon service problem** while preserving
the nominal plan whenever it is certified.  The benchmark does not show that
Zhong's controller is unsafe or inferior on its original two-gate asymptotic
regulation problem.  Its published guarantee and the manuscript's execution
certificate address different contracts.

