import unittest
import numpy as np

from run_reproduction import equilibrium_audit, simulate
from zhong_model import CASE_1, almost_smooth_gate, field, totals


class ZhongReproductionTests(unittest.TestCase):
    def test_reported_equilibrium_is_close_despite_printed_rounding(self):
        audit = equilibrium_audit(CASE_1)
        self.assertLess(audit["residual_inf_veh_per_s"], 2e-3)

    def test_controller_respects_requested_bounds(self):
        state = CASE_1.initial_state("perturbed")
        for bounds in ((0.1, 0.9), (0.2, 0.8), (0.4, 0.6)):
            gate = almost_smooth_gate(state, CASE_1, *bounds)
            self.assertGreaterEqual(float(gate.min()), bounds[0] - 1e-12)
            self.assertLessEqual(float(gate.max()), bounds[1] + 1e-12)

    def test_full_and_aggregate_dynamics_are_consistent(self):
        state = CASE_1.initial_state("equilibrium")
        gate = almost_smooth_gate(state, CASE_1, 0.1, 0.9)
        derivative = field(state, gate, CASE_1.demand)
        aggregate = np.array([derivative[0] + derivative[1], derivative[2] + derivative[3]])
        step = 1e-5
        numerical = (totals(state + step * derivative) - totals(state)) / step
        self.assertLess(float(np.max(np.abs(aggregate - numerical))), 1e-7)

    def test_primary_reproduction_converges_and_conserves(self):
        result = simulate(CASE_1, 0.1, 0.9, split="published", horizon_minutes=30.0)
        self.assertLess(result["final_total_error_inf_vehicles"], 25.0)
        self.assertLess(result["maximum_conservation_rate_residual"], 1e-12)
        self.assertGreaterEqual(result["minimum_state_vehicles"], -1e-9)


if __name__ == "__main__":
    unittest.main()
