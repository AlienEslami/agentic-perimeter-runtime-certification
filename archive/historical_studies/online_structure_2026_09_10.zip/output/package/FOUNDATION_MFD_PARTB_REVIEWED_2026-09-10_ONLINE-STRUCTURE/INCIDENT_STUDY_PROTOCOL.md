# Queue-aware incident and target-change study

Development protocol: 2026-09-10. The previously released six-state benchmark,
its proofs and all live proposal records are preserved.

## Question and fixed accounting

Can configuration-level certification support regional operating-target changes
through a substantial boundary-arrival event, while accounting for every waiting
vehicle and comparing service, total time spent, and computation fairly?

The new controlled benchmark adds one exterior staging reservoir to the existing
six destination-class states. It is a distinct commissioned model. At the base
equilibrium, boundary admission is 60 normalized units/hour (6,000 vehicles/hour)
instead of 2. Internal Region-2 demands are correspondingly reduced once, keeping
the original regional equilibrium and total equilibrium admitted throughput. All policies then use
the same fixed internal demands and the same externally specified offered-arrival
history; demand is never reconstructed separately for competing targets/policies.

Admission is min(60 z,120 u02) in normalized units/hour. The two destinations
receive equal shares. The queue is outside the regional accumulations. Total time
spent is the integral of 100(n1+n2+z); queue vehicle-hours and completed departures
are reported separately. Finite queue storage and the admission branch must be
included in every claimed safety verification. The queue is a staging reservoir,
not a spatial spillback simulator. Reaching its declared storage is an overflow
limit, not a simulated upstream shockwave.

## Development and evaluation separation

First establish feasible operating targets under common demand, synthesize local
feedback, and verify conservation and equilibria. Explore numerical feasibility
before freezing the controller library. Retain all discovery outcomes.

Predeclared incident family: boundary offered arrivals increase by 20%,30%,40%
for 30 or 60 minutes, with ramped onset and recovery. These are designed stress
scenarios, not observed incident records; percentages refer to the exterior
stream, not total city demand. Study predicted events and explicitly label any
unannounced event. A known event profile and bounded forecast residual are
separate mathematical inputs. A small residual is not a claim that the event
itself is small or that operational forecasts attain that accuracy.

Use a small library of feasible region-target configurations, with physical
states continuous at target changes. Each target's feedforward, gain, command
margins and landing/continuation record are recomputed. No arbitrary physical
state reset is allowed. Operator service thresholds remain physical quantities
and cannot improve merely by changing the reference used to report error.

## Comparison and guarantees

Compare the same library selector with and without the new certification layer,
and a physically constrained continuous-input MPC with matched forecasts,
sampling, horizon and objectives. A control-library restriction and certification
restriction are distinct effects. Queue/storage, regional service, completed
departures, total time spent and solver/verification latency are primary metrics.
Report nominal costs and disturbed replay outcomes, including null or unfavorable
comparisons. Do not tune queue capacities or incidents to guarantee a win.

Existing six-state tube and scalar dwell constants do not certify the augmented
model. Use fresh local synthesis and/or verified continuous finite-horizon
enclosures, including any queue-availability branch. An unsuccessful sufficient
test is unresolved feasibility, not physical impossibility. All uncertainty and
initial-state assumptions accompany the resulting claim. No Git push or new live
LLM calls are part of this phase unless separately requested.
