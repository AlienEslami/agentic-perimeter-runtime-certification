# Online structure-preserving revision - 10 September 2026

## Outcome

The structure-preserving finite-plan certificates are now integrated into
online replacement and retained execution, and the paper includes their
derivation, commissioning frontiers and complete online results. The new
work changes neither the physical plant nor the frozen scientific kernels.
No new live LLM call, Git commit, push, or Overleaf update was made.

The principal improvement is a larger certified operating range. The signed
method completes nominal one-hour missions with regional/class uncertainty
half-widths of 50 vehicles and a 120 veh/h arrival residual, or 25 vehicles
and a 300 veh/h residual. Queue half-width is capped at 10 vehicles. The
original and positivity/queue methods cannot certify initial activation
in those four matched cases. Unresolved activation is not assigned a zero
traffic cost or described as a physical violation.

The binding-service result makes certification economically consequential.
With a trusted 1700-vehicle one-hour deadline and the same 1600-target
commissioning commands, all three methods execute identical trajectories:
two admitted plans and ten rejected replacements with retained execution.
Independent TTS is 4584.699936 veh-h, against 4428.736221 for matched nominal
request replay (a 3.521630% premium). The signed method additionally certifies
a 1625-target commissioning plan. Its online TTS is 4543.499291 veh-h,
a 2.591328% premium over its matched nominal replay. This saves 41.200645
veh-h (0.898655% of the common-plan certified cost), without a higher online
acceptance count. The gain comes from the certified commissioning margin.

The earlier held-plan commissioning result remains separate: 41.333422
veh-h (0.901296%) saved on the frozen six-target grid. It is not substituted
for the online result. All commissioned options satisfy the same authorized
service bound under their declared uncertainty contract.

## Protocol and failure accounting

`STRUCTURE_ONLINE_RUNTIME_PROTOCOL.md` freezes 17 runs: 13 certified nominal
cases, three nominal request-replay comparators and one certified adverse
diagnostic. All were completed as declared, including four unresolved
initializations. A completed experiment menu does not mean every proposed
activation succeeded. The adverse case uses an in-box initial displacement,
nonzero bounded sensor bias and a fixed alternating arrival residual; it is
excluded from nominal cost comparisons.

Semantic inputs are replayed from the archived primary-model stateful
episode, with MPC reoptimized on each current state. These are not new live
calls receiving feedback from the revised checker. The 32-call live pilot
and the 240-call stationary study keep their original, distinct scope.
The primary-model pilot has 0/6 correct contextual requests in each interface;
the paper reports that failure and the complete denominators.

## Mathematical changes

- A new structure-preserving plan proposition states the constant-command
  domain and links positivity, scalar queue comparison, signed initial-state
  generators and the robust nonlinear remainder to continuous constraints
  and scheduled service.
- A complete appendix gives the positive-cone and nonescape argument,
  constant and affine-arrival queue comparisons, predictor-to-state branch
  corridor, mean-value remainder identity, Metzler comparison, signed output
  supports, numerical recentering and matrix-series tails.
- The existing closure theorem covers both enclosures. A rejection preserves
  the original accepted universal proof and exact suffix; outer-hull
  membership never authorizes a correlated restart. A replacement uses a
  new sound timestamped physical observation box.
- Full artifact bytes and a trusted verifier registry are distinguished from
  a descriptor hash or proposer-supplied acceptance flag. Exact commands,
  clocks, model/task assumptions and original expiry are bound to execution.
- Reachability and dependence-preserving prior work is acknowledged. The
  contribution is the transportation-specific construction and its execution
  composition, rather than a claim to invent general zonotope or dwell theory.

## Verification

The independent online audit passes all 17 case records, 124 proof records,
160 timestamped information-box checks and 46 retained epochs. Forty
negative authority tests and five positive controls pass. Independent
class-balance replay has maximum decision-epoch discrepancy 0.001237 vehicles
and TTS discrepancy 0.001735 veh-h. Three additional nonzero-clock/sensing
probes pass, including a correlated-set versus outer-hull counterexample.
Saved high-precision and exact-arithmetic audits of the unchanged kernels
are included alongside the new execution tests. These checks are kept
distinct from a formally verified numerical software implementation.

Both manuscript layouts are built from the same mathematical content and
cross-reference audited. The release packaging verifies payload hashes,
retention of earlier experiment records and the raw live archives. Figures
and revised mathematical pages are visually inspected after compilation.
The archive contains complete sources, proofs, simulations, protocols,
audits and historical diagnostics; model weights and local caches are excluded.

## Remaining deployment work

The new frontiers are designed-model commissioning results. Wider regional
uncertainty does not imply a calibrated city estimator, and the 100-vehicle
fixed-plan cell remains unresolved. The arrival band concerns additive
exterior demand, not arbitrary MFD-parameter or receiving-supply uncertainty.
The implementation assumes synchronous activation. A deployment must
propagate the incumbent set through sensing and computation delay and
commission the resulting activation set. Trusted state sensing, model/task
integrity and actuator adherence remain explicit execution assumptions.

For the language interface, structured task memory and consistency checks
between stated intent and requested objective are still a distinct improvement
to test on held-out paraphrases. The physical certifier enforces its trusted
service and safety rows, not the correctness of every soft semantic priority.
