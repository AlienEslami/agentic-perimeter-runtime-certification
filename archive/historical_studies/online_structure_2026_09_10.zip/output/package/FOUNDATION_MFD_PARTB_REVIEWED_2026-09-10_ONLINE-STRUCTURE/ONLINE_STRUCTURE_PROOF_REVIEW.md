# Online admission and retention of structure-preserving plan certificates

Independent review, 2026-09-10. This note concerns the new online integration of
the frozen affine-v3 encloser, and does not modify the old runtime or results.
Reviewed inputs are `manuscript_streamlined/core_certification.tex`,
`reproducibility/mfd_incident_agent_runtime.py`,
`reproducibility/mfd_incident_mpc_runtime.py`, the common plan verifier, and
`reproducibility/mfd_incident_affine_reachability.py`.

## 1. Main finding

The existing finite-plan execution-closure theorem applies to the new
structure-preserving enclosure. Its induction requires sound continuation
certificates, exact execution binding, and sound information at installation;
it does not require the reachable sets to be boxes. The online implementation
must retain the original accepted proof when a replacement fails. It must not
replace that proof's correlated sets by their outer boxes and then reuse the
old suffix certificate as if it had been proved from the larger set.

The recommended paper change is to generalize the **existing** closure
statement to the two sound enclosure constructions and to add one precise
paragraph on retained-proof semantics. A second near-duplicate closure theorem
would add notation without a distinct mathematical result.

## 2. State, information, and trusted task

Let the physical state be x, the agent's internal state be m, and a trusted
measurement at installation time t_k be

\[
 z_k=x(t_k)+v_k,\qquad |v_k|\le\varepsilon_k,
 \qquad X_k=z_k+[-\varepsilon_k,\varepsilon_k].
\]

The deterministic sensing hypothesis is x(t_k) in X_k. The certifier proves
statements **from** X_k; it does not infer that the sensor satisfies its error
bound. The agent may use a different estimate or corrupted memory to generate
its request. The supervisor obtains X_k, the timestamp, and the commissioned
sensor bound through the trusted interface, not from that request.

The trusted contract C contains the plant/model version, physical rows,
absolute forecast and residual class, sensing contract, and versioned service
rows (g_r,T_r,eta_r). An objective request may affect the planner's objective;
it does not alter C. For a fresh proof, independently verify the entire declared
initial physical box as required by affine v3. A box crossing the positive
class boundary may cause rejection even if its center is physically feasible.
Silently clipping such a box changes the information-set semantics and is not
part of this adapter.

The pending task at t_k contains each not-yet-discharged row with T_r >= t_k.
At an exact deadline, discharge the row under the current proof before marking
it complete, or include it as an initial-time check in the replacement. Never
drop a still-pending row because the proposed horizon is shorter.

## 3. What an accepted proof establishes

Write a candidate plan as

\[
 P=(t_k,E,\{(\tau_b,u_b)\}_b,X_k,C),\qquad
 t_k=\tau_0<\cdots<\tau_B=E.
\]

For the new implementation u_b is an exact binary constant command. A sound
accepted certificate establishes, for every x_k in X_k and every admissible
measurable residual on [t_k,E], continuous physical admissibility and all
included service rows. Its statement is about the exact absolute schedule;
the optimizer's simulation tolerance is not a certificate premise.

There are two distinct identities:

- A descriptor identifier binds the mathematical inputs: state information,
  commands, block times, forecast, residual, constraints, and service rows.
- A full artifact hash and trusted verifier provenance bind the actual proof
  evidence and acceptance result. The existing `proof_id` hashes the descriptor,
  not every field of the certificate record. A valid descriptor hash alone
  cannot authenticate a supplied `accepted=True` flag.

The runtime must obtain certificates from the trusted local verifier, retain
their immutable artifact reference, and check the descriptor against the
current installation transaction. Agent-produced text must never become a
trusted certificate merely by presenting a hash.

## 4. Online authority invariant and closure proof

At each decision time t_k retain an active immutable proof P_i, activated at
t_i <= t_k, with original expiry E_i. The authority invariant is:

1. P_i was accepted by the trusted verifier for a sound installation set at
   t_i and the active trusted contract.
2. The actual command on [t_i,t_k) equals the absolute schedule certified in
   P_i; actual disturbances satisfy P_i's uncertainty assumptions.
3. Every pending service deadline lies within P_i's validity interval.
4. The next authorized execution interval lies inside [t_k,E_i].

For a fresh request, the supervisor may install P_k only after its new proof
passes and its initial set is sound at the actual installation instant. It
need not prove X_k is contained in the old reachable set: P_k establishes its
own universal continuation guarantee from X_k. The actual state belongs to
X_k by the sensing hypothesis, which is the required link.

If the request or proof fails, do not install anything and do not reset any
uncertainty. Execute P_i's already certified command on the next interval,
provided that interval does not exceed E_i. The flow theorem for P_i, applied
to its actual original initial state and actual executed prefix, already
establishes the continuation guarantee. No new checkpoint membership premise
is needed to derive it.

**Proof.** The invariant holds at task activation by the first accepted proof.
If the request is rejected, the original universal plan statement applies to
the actual initial state, allowed disturbance history, and unchanged command
schedule; restricting its conclusion to the unexecuted suffix preserves all
remaining conclusions. If a replacement is accepted, its sound installation
set contains the same continuous physical state at the switching instant, and
the new universal plan statement establishes the invariant with i=k. Induction
over the finite decision grid yields continuous physical admissibility and
each scheduled service result. The final interval terminates at its active
absolute expiry. A later interval needs a separately accepted continuation.

This argument does not use the agent's numerical trajectory as a proof and
does not substitute a fresh sensor box on a rejection branch.

## 5. Correlated checkpoints and why the outer hull is insufficient

The affine method propagates an enclosing family

\[
 \mathcal R_l=\{p_l+L^{-1}(G_l\xi+\eta):
                  |\xi|\le1,\ |\eta|\le\rho_l\},
\]

together with independently established positivity and scalar queue facts.
Its coordinate hull H_l generally contains additional states. For an exact
two-dimensional example, let p=(2,2), G=(1,1)^T, and rho=0. Then

\[
 \mathcal R=\{(2+s,2+s):|s|\le1\},\quad H=[1,3]^2.
\]

The row x_1-x_2 <= 0 holds throughout R, but the point (3,1) belongs to H and
violates it. This remains a counterexample under zero dynamics: membership in
an outer hull is not authority to reuse a statement proved on the correlated
set. A runtime diagnostic that checks a simulated point against H is useful
for detecting numerical/provenance errors, but passing that diagnostic adds
no new execution authority.

The distinction is not specific to rank-deficient generators. Small positive
remainder widths give full-dimensional examples with the same failure of a
box-hull restart. Conversely, a **new** independently accepted certificate
from the entire outer hull would be sound, though often conservative. It is
the unproved reuse of the old suffix, not an independently verified larger
initial set, that is invalid.

## 6. What must be stored

For execution of a fully preverified suffix, the runtime needs an immutable
accepted parent artifact (or a trusted reference to it), exact command blocks
and absolute times, original activation and expiry, trusted contract identity,
and a contiguous execution-history cursor. The full artifact retains the
initial information, enclosure proof, and all auxiliary premises. The runtime
does not need to numerically propagate G_l or rho_l again just to execute an
already certified suffix.

An executed-prefix hash is an integrity aid, not evidence by itself that an
actuator obeyed its command. The mathematical assumption is exact execution;
the simulation audit independently reconstructs the commands and trajectory.
A deployed system needs a trusted actuator/execution interface consistent with
that assumption.

If a future implementation supports a genuine correlated-set restart, it must
store and validate at least p_l, L, G_l, rho_l, their outward arithmetic and
clock binding, **and** every auxiliary fact used by the future proof. For v3,
these include the independent queue interval and positive-class premises: the
future Jacobian corridor is tightened with those facts. G_l and rho_l alone
are not the complete proof state. A fresh restart API then needs a separate
containment/continuation proof. The current `initial_shape` prohibition avoids
silently supplying such an API.

## 7. New measurements during retention

If both a measurement set and a retained reachable set are sound, their
intersection is sound. But computing or enclosing that intersection is a new
set operation: it must preserve the actual state and every dependency used by
the subsequent proof. The current retention path needs no intersection.

A fresh measurement box need not be a subset of the retained set. It can be
much wider in one direction while still containing the true state. Rejecting
all such measurements would impose an unnecessary admission condition.
If the two allegedly sound sets are disjoint, their premises are inconsistent.
Do not replace the inconsistency by an empty initial set and a vacuous
certificate. Log an information/assumption fault and decline the fresh
installation. Continued use of the old plan remains conditional on the old
model, disturbance, execution, and original sensing premises; a new sensor
fault does not retroactively prove those premises false or true.

For simulated biased sensing, apply a predeclared bias inside the declared
box and verify exact containment of the independently propagated actual
state. Floating corners require care: computing x+epsilon can place the exact
binary difference one ulp outside an intended binary epsilon. Use exact
rational checks or an inward neighboring floating value. Bias outside the
declared bound is an assumption-violation test, not an admissible disturbance.

## 8. Absolute time and computation delay

The v3 derivation is time-local and remains valid for nonzero initial time.
The implementation passes exact rational left/right times to the absolute
forecast and partitions at its actual knots, command changes, and service
times. Its fresh initial generator is initialized from the new physical
measurement box. It does not inherit an old G/rho state on a replacement.

The frozen v3 source's original experiment/protocol is a first archived-plan
study. Reusing its mathematics online therefore requires a new adapter and
online study protocol, with actual nonzero installation time, remaining
durations, and pending service checks bound in every candidate descriptor.
Keep the original method source/protocol provenance intact rather than
rewriting the old protocol as if it had specified the online experiment.

Synchronous simulation has zero modeled decision latency and reports measured
computation time separately. For asynchronous deployment, a measurement at
t_obs cannot authorize installation at t_install merely by relabeling its
timestamp. Propagate its sound set under the still-authorized command to the
actual installation time, or obtain a fresh sound installation set. The
replacement proof must begin from that set at t_install. If the old plan would
expire before computation/installation completes, the supervisor has no
proved bridge through the gap.

## 9. Recommended concise manuscript text

Add after the existing admission paragraph:

> Each accepted replacement is certified from the trusted measurement set at
> its installation time. After rejection, the supervisor retains the original
> accepted plan, its exact command schedule, uncertainty assumptions, service
> deadlines, and absolute expiry. For the structure-preserving enclosure, this
> also retains the correlated reachable-set proof and its auxiliary queue
> bounds. Coordinate-box checkpoints support execution diagnostics; they do
> not initialize a replacement proof or enlarge the certified suffix domain.

Amend the existing closure theorem's first sentence and proof reference:

> Suppose each accepted plan carries a sound finite-plan certificate obtained
> from either enclosure construction, and its trusted installation set contains
> the actual state. The initial plan and every accepted replacement cover all
> pending service rows under the active commissioned contract.

Use the existing induction proof with “certified reachable sets” in place of
“boxes.” Preserve the original-expiry conclusion and actual-installation-time
condition. Put the correlated-set/outer-hull distinction and proof-state list
in the appendix. No second five-assumption online theorem is needed.

## 10. Bounded adversarial guard tests recommended to implementation

The independent runtime audit should exercise at least:

- accepted descriptor, artifact and trusted method/source identities;
- rejection of a failed certificate even when its input descriptor is valid;
- changed acceptance/evidence fields without an updated trusted artifact;
- one-ulp changed command, block duration, initial center, or sensing width;
- a stale/future measurement timestamp and wrong installation timestamp;
- changed model, forecast, residual, service limit, deadline, or task version;
- a missing pending service row and a horizon ending before its deadline;
- a skipped, repeated, or noncontiguous execution clock;
- execution across a certified command-block boundary with the wrong command;
- execution beyond expiry, including relabeling an old proof as a fresh plan;
- commit of a command other than the authorized command;
- failed installation leaving the active parent immutable;
- checkpoint outer-hull membership failing to create restart authority;
- sound biased sensing and a deliberately out-of-bound sensing countercase.

These are fail-closed authority checks. They test exact binding and assumption
handling; they do not replace the mathematical reachability proof.
