# Queue-aware MPC uncertainty frontier: frozen protocol

This protocol is recorded before running the uncertainty sweep. It is a numerical
operating-range experiment, not an empirical calibration or an uncertainty model
estimated from traffic data. Every attempted certificate and failure is retained.

## Fixed experiment

- Use the archived first MPC plan of the primary 30% / one-hour incident in
  `reproducibility/results/mfd_incident_mpc_grid_results.json`, without resolving
  the optimization or changing any binary command coefficient.
- Its two command blocks last exactly 1/12 and 11/12 hour, beginning at time zero.
- Preserve the seven-state model, cubic MFD, known incident forecast, physical
  constraints, 2,000-vehicle queue storage and regional service requirement
  `n1(1 hour) <= 2,850 vehicles`.
- Use the existing conservation-coordinate componentwise certificate, exact
  constant-command actuator audit and 15-second maximum verification step.
- These are finite-plan certificates, not closed-loop performance studies. A
  failed certificate is not evidence of an unsafe physical trajectory.

## Uncertainty sets and axes

Physical coordinates are `(n1,n2,n11,n22,n10,n20,z)`, with 100 vehicles per model
unit. The first six half-widths are a common `v` vehicles. The exterior queue
half-width is `min(v,10)` vehicles: queue sensing is treated as a separate input
from accumulation/class estimation. Thus a derived class such as `n12=n1-n11-n10`
can vary by up to `3v`, and this correlation is carried through the installed
coordinate map. Before verification, exact binary-rational affine support checks
classify whether the whole initial set satisfies physical constraints. Invalid
initial sets are reported separately and are not counted as enclosure failures.

1. At a 60-vehicle/hour arrival residual, test `v = 1,5,10,25,50,100` vehicles.
2. At `v=1`, test arrival residual bounds `60,120,300,600,1200` vehicles/hour.
   The residual is any measurable additive error around the fixed forecast.
3. Near the tested frontier, cross the largest accepted axis value and the first
   subsequent failed value on each axis. If an axis entirely passes, use its two
   largest tested values; if entirely fails, use its first two values. Reuse rows
   already evaluated rather than running duplicate proofs.
4. Coordinate ablation: test class-only and raw physical box coordinates at the
   baseline and at the largest accepted state-error axis value. Keep all commands,
   physical input sets and numerical settings identical.
5. Scalar/vector sanity check: separately verify the baseline scalar one-vehicle
   half-width and its seven-entry vector representation. Their descriptor, output
   bounds and acceptance must agree exactly (wall-clock time is excluded).

The initial budget is at most 35 full proofs. The declared axes and deterministic
selection above require fewer than that; further extensions require a dated
protocol amendment before their outcomes are observed.

## Recorded outputs

For each row record the exact initial state and widths, residual, metric, command
plan and source hashes; initial-set validity; the full proof with interval-step
records; admission and scheduled-service upper bound; first failure kind,
constraint and time; verification time and maximum transformed radius. Distinguish
failure of initial admissibility, first-exit self-inclusion, continuous physical
supports and scheduled service. A row that stops before the deadline has no valid
deadline bound. Report the largest *tested* successful values, not a necessary
threshold or a calibrated deployability claim.

This experiment does not enlarge the contract of any previously admitted plan.
Runtime rejection/retention and live-agent experiments are separate studies.
