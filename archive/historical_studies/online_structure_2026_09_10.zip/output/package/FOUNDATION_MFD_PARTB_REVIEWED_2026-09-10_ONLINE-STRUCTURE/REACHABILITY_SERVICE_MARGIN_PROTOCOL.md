# Matched commissioning-margin protocol

Frozen before the new grid is run, 2026-09-10.

Question: does a tighter reachable-set certificate reduce the nominal traffic
cost of commissioning the **same** trusted task, n1(1 hour) <= 1700 vehicles?

Use the unchanged seven-state two-region queue model, its original physical
initial state, 30% one-hour demand pulse, network-plus-queue TTS objective,
one-hour prediction horizon, and two constant command blocks of exactly
1/12 and 11/12 hour. The physical initial information box has independent
half-widths of 1 vehicle in all seven coordinates; the arrival residual is
bounded by 60 vehicles/hour. The service test is always 1700 vehicles at
exactly one hour, independently of the optimizer's internal margin.

Solve the nominal MPC once for each internal target, in this order:
1700, 1690, 1675, 1650, 1625, and 1600 vehicles. Use the unchanged original
three starts, solver tolerances, integration grid, constraints, and objective.
No target-specific warm start, control repair, or extra search is introduced.
Preserve every optimizer attempt and its exact selected binary commands.

Verify each selected command plan, without changing it, with three methods:

1. Original ConstantCommandVerifier.
2. PositiveVerifier('positive_queue').
3. Frozen AffineGeneratorVerifier v3, retaining its existing method provenance.

All methods use 15-second proof steps, the same trusted task, exact clock,
initial information set, disturbance family, actuator constraints, and physical
requirements. Save complete proof records, including failures. The existing
v3 method protocol describes its original uncertainty experiment; this separate
protocol governs the new service-margin experiment and is bound to every new
artifact. The actual commands and 1700-vehicle task are bound in each proof's
descriptor. No existing protocol or result file is modified.

Independently replay each selected plan using the separate class-balance
reference field and tight adaptive integration. Report nominal TTS, deadline
state, prediction-discretization error, and sampled physical margins, with the
sampled replay distinguished from the continuous-time certificate. Optimizer
failure to find a feasible plan is not a proof of infeasibility. A failed
certificate is not evidence that the physical trajectory violates its task.

For each checker, identify the smallest nominal TTS **among that checker's
certified points in this same six-point grid**. Compare these matched-grid
minima, not an old hand-selected 1600-vehicle plan against a newly optimized
grid. Retain all costs and proof failures. This is a discrete commissioning
study, not a continuous optimum or a physical feasibility frontier. Do not
retune or add targets after observing outcomes in this protocol.

Audit source and protocol hashes, identical plan fingerprints across methods,
exact proof descriptor hashes, initial box, disturbance, service task and
horizon, and independent replay agreement. Preserve executable source
snapshots alongside full proofs.
