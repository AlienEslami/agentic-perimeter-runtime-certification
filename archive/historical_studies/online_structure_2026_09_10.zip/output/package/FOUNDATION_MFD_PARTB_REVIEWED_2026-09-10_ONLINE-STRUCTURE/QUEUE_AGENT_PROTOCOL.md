# Queue-aware live-agent pilot: frozen protocol

Version: `queue-semantic-agent-v1-20260910`.

## Question and evidence unit

Can a live language-and-memory component interpret sequential operator instructions, request an MPC objective on the seven-state queue-aware transportation plant, and receive actual proposal/certification/execution feedback? The comparison isolates access to agent memory. It is a one-model interface pilot, with every attempted call and every runtime outcome retained regardless of result.

## Fixed live-call budget

Use the already installed local Ollama model `qwen3:8b`; archive its full installed model record/digest. No model downloads. Temperature zero, non-thinking mode, seed `20260910 + call_index`, up to 400 generated tokens, no automatic retries. Two fixed paraphrases of one eight-decision semantic trace are each run with stateful and memoryless interfaces: **32 live calls total**, 16 per variant, including six contextual requests per variant. This is not a model ranking or population-level test.

The machine-readable protocol, language trace, expected requests, schema, cost rows, and call cap are written to `frozen_protocol.json` before any call. Every session records the source-file and frozen-protocol SHA-256. Request records use exclusive creation and are saved before HTTP dispatch; raw response and execution records are also exclusive and never replace prior evidence. The four session identities exhaust the 32-call design. A subsequent pilot needs a new directory/protocol, not a rewrite of these records.

## Physical and decision timeline

At minute 0 an independent network-objective MPC plan is commissioned and verified. This is a deterministic initialization, not a live language-model decision. Live calls occur at minutes **5, 10, 15, 20, 25, 30, 35, and 40**. The runtime continues five-minute reoptimization with the last requested objective to the minute-60 deadline without additional live calls. All trace comparisons use the same one-hour physical evaluation window and fixed event/uncertainty contract supplied by the experiment driver.

Each live call uses the actual current plant summary and actual previous execution feedback. The module does not generate a synthetic acceptance flag, simulated outcome, or substitute trajectory. The caller supplies the actual MPC and certifier records and advances the real simulation before the next live call.

## Task trace fixed before calls

| Decision minute | Instruction semantics | Expected objective | Objective window | Context needed? |
|---|---|---|---|---|
| 5 | Stadium release: prioritize Region 1 | `region_1` | 60 min | No |
| 10 | Continue current response | `region_1` | 60 min | Yes |
| 15 | Restore network-wide operation | `network` | 30 min | No |
| 20 | Freight surge: prioritize Region 2 | `region_2` | 90 min | No |
| 25 | Continue current response | `region_2` | 90 min | Yes |
| 30 | Temporary emergency-access override in Region 1; remember interrupted response | `region_1` | 5 min | No |
| 35 | Return to the interrupted response and its window | `region_2` | 90 min | Yes |
| 40 | Restore network-wide operation | `network` | 30 min | No |

The two complete natural-language paraphrases are literal constants in `reproducibility/mfd_incident_live_agent.py` and in the frozen JSON. Expected requests are recorded separately and never supplied to the model. The incident labels motivate changing operator objectives; they do not silently change the frozen arrival process or physical contract.

## Agent state and tool binding

The output has exactly three fields: `objective`, `duration_minutes`, and `memory_update`. The latter is at most 500 characters and is produced by the live model. The stateful variant receives that previous memory; the memoryless variant does not. Both receive identical types of plant and execution information. Previous requested objectives, durations, and optimizer scores are excluded from the feedback visible to either variant, so the memoryless variant is not handed the missing context through a different channel. Physical trajectories can, of course, carry information about prior executed commands.

The language model does not compare printed scalar scores or choose among displayed controller costs. It maps the instruction and memory to an MPC tool request. With state order `(n1,n2,n11,n22,n10,n20,z)`, the runtime maps objective labels to fixed cost rows:

- `network`: `(1,1,0,0,0,0,1)`;
- `region_1`: `(4,1,0,0,0,0,1)`;
- `region_2`: `(1,4,0,0,0,0,1)`.

The vehicle-hour scale multiplies the integral by 100. Regional weights apply for the first `min(requested duration, plan horizon)` minutes of a candidate prediction; the network cost applies afterward. The objective window is distinct from the proof horizon. All pending service deadlines and the entire submitted plan remain covered by certification. Repeated tool requests at later decision epochs start their objective window from that epoch; this is logged as receding-horizon interpretation, not a hidden extension of any proof's expiry.

## Trusted contract and rejection handling

The initial study fixes Region 1 accumulation at minute 60 to at most 2850 vehicles and exterior storage to at most 2000 vehicles. Full state/input constraints, uncertainty, and plan validity are supplied independently by the runtime. The agent cannot redefine these fields; extra output keys fail strict parsing. A malformed request generates no new MPC tool request, and the runtime applies its existing retained-plan rule.

A candidate optimizer plan is executed only after the actual certifier admits it. Rejection retains the previously certified suffix under its original contract and original expiry. No reported fallback is manufactured by forcing a rejection flag. The driver records optimization failures, certificate failure reasons, retained validity, first commands, service values, queue values, and TTS. If no certified initialization or valid suffix exists, the driver must stop or report failure; the interface itself provides no fallback certificate.

The initial 32 calls have no memory-corruption intervention. Any later prescribed corruption is a separately labeled, frozen intervention with its own call budget and provenance; it is not evidence of a naturally occurring attack.

## Outcomes and audit

Report all 32 attempted calls, valid structured requests, correct objectives, correct durations, exact correct request pairs, and explicit/contextual denominators. Report per-trace MPC feasibility, admissions, genuine rejected replacements, retained-suffix execution, physical/service outcomes, total queue-inclusive vehicle-hours, and latency. Correct intent interpretation and physical safety are different outcomes. The independent certifier can admit a physically valid plan produced for a misunderstood soft objective.

The default feedback allowlist is checked in code. Raw runtime records remain unabridged in per-step execution files. The self-test verifies strict schema, fixed cost rows, rejection of attempted hard-contract amendments, no explicit objective leakage into memoryless prompts, the 32-call design, and three contextual decisions per trace. It makes zero live calls.

## API and reproduction

`QueueAgentSession(output_root, variant="stateful", paraphrase=0)` prepares one trace. At each frozen decision:

1. Call `session.propose(step_index, time_minutes, state_summary, execution_feedback)` with actual observations and previous runtime feedback. At the first call, feedback is from minute-0 certified commissioning.
2. If `valid`, pass `tool_request.cost_row` and `tool_request.priority_minutes` to the objective-parameterized MPC tool. Keep the proof horizon and hard contract under runtime control.
3. Run the real certification/execution step.
4. Call `session.record_execution(step_index, actual_feedback)` before requesting the next live decision.

The module's CLI provides `--self-test`, `--list-models`, and `--freeze-protocol PATH`. It has no standalone fake-physics live runner. The integrated experiment driver owns the actual closed-loop experiment.
