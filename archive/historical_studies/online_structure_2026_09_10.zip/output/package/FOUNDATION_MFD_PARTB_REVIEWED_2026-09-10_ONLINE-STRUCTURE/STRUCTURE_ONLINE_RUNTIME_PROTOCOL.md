# Frozen structure-aware online finite-mission study

This protocol is fixed before the new online outcomes are computed. Existing
scientific modules, proof files, protocols, live requests and numerical results
are read-only inputs. No new LLM calls are authorized by this experiment.

## Mission and matched experiment menu

The seven-state primary 30% one-hour arrival event, binary plant coefficients,
one-hour absolute service deadline and five-minute proposal clock are unchanged.
Every proposal is evaluated against the same remaining absolute deadline.
The 12 structured requests from archived p0-stateful queue-agent execution are
replayed in order; the MPC is recomputed on each method's current information.
This is semantic-request REPLAY, not a new live interaction with the certifier.

The certified menu comprises:

1. Initial physical-coordinate half-width 1 vehicle, residual 60 veh/h, service
   2850 vehicles: original, positive_queue and affine_v3 kernels.
2. Width 50 vehicles, residual 120 veh/h, service 2850: the same three kernels.
3. Width 25 vehicles, residual 300 veh/h, service 2850: the same three kernels.
4. Width 1 vehicle, residual 60 veh/h, service 1700: the three kernels use the
   same archived commissioning plan with nominal target 1600 vehicles.
5. One additional affine_v3 deployment uses archived commissioning target 1625
   for the same trusted service 1700. These two targets were selected by the
   completed, frozen service-margin grid; this is an explicitly different
   commissioning design, not a matched-command superiority comparison.

These are 13 nominal-realization certified runs. Three nominal MPC semantic
request-replay comparators use the corresponding commissioning plans: the
2850 plan, service1700/commissioning1600, and service1700/commissioning1625.
The single nominal2850 realization is shared across uncertainty-width contracts.
Failed commissioning is recorded as unresolved initialization and executes no
unproved fallback. Every optimizer failure and certificate rejection is retained.

A fourteenth certified run is a separately reported adverse diagnostic for
affine_v3, width25/residual300/service2850. Its true initial state is the declared
commissioning information center plus one-half the coordinate widths times
(+1,-1,+1,-1,+1,-1,+1). Actual arrival residual is +300,-300,+300,-300 veh/h on
successive quarter hours. After initialization the observation bias is one-half
the widths times the same sign vector times (-1)^epoch. All true states must lie
in their declared fresh information boxes. This selected adverse realization
is a diagnostic, not a worst-case or calibrated stochastic experiment, and is
excluded from nominal TTS comparisons.

## Uncertainty and information assumptions

The six regional/class physical-coordinate widths equal the declared width;
the queue width is min(width,10) vehicles. Initial boxes are physical axis-aligned
sets, with exact binary center/width values recorded. Subsequent boxes are
trusted fresh observations of the current actual state, stamped with the exact
installation epoch. Nominal runs have zero observation bias and zero actual
arrival residual; the declared uncertainty bands remain robust contracts.
The sensor contract assumes the actual state belongs to each current box; the
simulation checks this condition independently of certification. Certificates
establish consequences of these sound boxes, not sensor truthfulness.

## Online authority and finite-plan composition

Each candidate is certified from the fresh physical information box, with the
original absolute arrival clock, immutable physical/model/task contract and
absolute mission expiry. No initial_shape API or nominal radius reset is used.
Original, positive_queue and affine_v3 are separate kernels, not an outcome-
selected portfolio. Scientific kernel sources and their original protocols
remain unchanged; this online protocol separately binds their new use.

A trusted local proof store writes the entire proof artifact, including every
step's correlated G/rho, auxiliary scalar queue enclosures and positivity
premises, and registers its full byte hash. The online authority never accepts
an agent-supplied proof or relies only on a descriptor hash/accepted flag.
Installation binds the full artifact, certified method, sensor observation,
model/task contract, exact installation timestamp, commands, durations, original
expiry and accepted/executed history hashes. Synchronous logical installation
is assumed; computation times are recorded, not treated as zero-latency hardware
measurements.

On rejection, the original accepted proof and exact original command suffix
remain installed. Every executed interval must be contiguous with its verified
prefix, use the original command, preserve its assumptions and end no later
than its original expiry. The accepted proof is never rewritten. Outer-hull
membership checks are diagnostic only and cannot authorize correlated-set
restart, a new suffix proof, or changed assumptions. A fresh accepted box need
not be contained in the predecessor reachable set because it independently
contains the actual current state. The mission terminates at the absolute expiry;
no recursive-feasibility or infinite-horizon assertion is added.

## Reporting, integrity and bounded execution

For each attempted plan save the optimizer/request, trusted information box,
full proof or explicit failed-precondition record, artifact/source hashes,
admission result, exact executed command, retained parent identity and expiry,
execution-history chain, and diagnostic hull membership. Report initialization,
accepted/rejected/retained counts, nominal/adverse realized service, TTS, queue
delay, departures, sampled physical margins and mass balance. A certificate
failure is not a physical-violation witness. Rejections are not forced outages.

All 17 declared runs are retained. The execution order starts with baseline
and binding affine cases, then completes the fixed menu. No new scenario,
kernel change or tuning is introduced in response to these outcomes. Independent
authority mutation tests and class-balance replay check the saved results.
