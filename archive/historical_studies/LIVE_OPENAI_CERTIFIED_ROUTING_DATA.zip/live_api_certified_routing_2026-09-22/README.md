# Live API certified-routing experiment

This directory contains the frozen OpenAI protocol and runner for three runtime situations:

1. an economical MPC plan is certified and installed unchanged;
2. an MPC plan is rejected, predictive repair is requested, and the certified repair is installed;
3. the same MPC plan is rejected, the repair service hits a declared 30-second cutoff, and the verified backup remains active.

The language model only selects orchestration tools. The deterministic execution-authority layer checks exact plan/verdict binding. Traffic outcomes are replayed from the archived, independently checked manuscript evidence; an API response cannot authorize an uncertified command.

Run:

```powershell
python run_live_api_routing.py
python audit_results.py results/<run-id>
```

Credentials are read from `OPENAI_API_KEY_FILE`. Request artifacts omit authentication headers and secrets.
