#!/usr/bin/env python3
"""Independently recompute core counts and artifact bindings for one live run."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def canonical_bytes(obj: object) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=Path)
    args = parser.parse_args()
    run_dir = args.run_dir.resolve()
    protocol = json.loads((run_dir / "protocol_snapshot.json").read_text(encoding="utf-8"))
    expected_hash = (run_dir / "protocol_sha256.txt").read_text(encoding="utf-8").strip()
    actual_hash = hashlib.sha256(canonical_bytes(protocol)).hexdigest()
    episodes = json.loads((run_dir / "episodes.json").read_text(encoding="utf-8"))
    summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
    stages = [stage for episode in episodes for stage in episode["stage_records"]]

    errors: list[str] = []
    if actual_hash != expected_hash:
        errors.append("protocol hash mismatch")
    if summary["protocol_sha256"] != expected_hash:
        errors.append("summary protocol hash mismatch")
    if summary["episodes"] != len(episodes):
        errors.append("episode count mismatch")
    if summary["stage_decisions"] != len(stages):
        errors.append("stage-decision count mismatch")
    if summary["correct_stage_decisions"] != sum(int(s["score"]["stage_correct"]) for s in stages):
        errors.append("correct-stage count mismatch")
    if summary["complete_workflows_correct"] != sum(int(e["workflow_correct"]) for e in episodes):
        errors.append("workflow count mismatch")
    if summary["executed_storage_violations"] != sum(int(e["outcome"]["executed_storage_violation"]) for e in episodes):
        errors.append("storage-violation count mismatch")
    if summary["executed_service_violations"] != sum(int(e["outcome"]["executed_service_violation"]) for e in episodes):
        errors.append("service-violation count mismatch")

    for stage in stages:
        response_path = run_dir / stage["raw_response_file"]
        if not response_path.exists():
            errors.append(f"missing response artifact {response_path.name}")
            continue
        response = json.loads(response_path.read_text(encoding="utf-8"))
        if response.get("protocol_sha256") != expected_hash:
            errors.append(f"protocol mismatch in {response_path.name}")
        if response.get("prompt_sha256") != stage["prompt_sha256"]:
            errors.append(f"prompt mismatch in {response_path.name}")

    report = {
        "audit_passed": not errors,
        "protocol_sha256": actual_hash,
        "episodes_recomputed": len(episodes),
        "stage_decisions_recomputed": len(stages),
        "correct_stage_decisions_recomputed": sum(int(s["score"]["stage_correct"]) for s in stages),
        "complete_workflows_correct_recomputed": sum(int(e["workflow_correct"]) for e in episodes),
        "executed_storage_violations_recomputed": sum(int(e["outcome"]["executed_storage_violation"]) for e in episodes),
        "executed_service_violations_recomputed": sum(int(e["outcome"]["executed_service_violation"]) for e in episodes),
        "errors": errors,
    }
    (run_dir / "audit.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
