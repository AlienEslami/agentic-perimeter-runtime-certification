# Live OpenAI agent-routing results

## Design

- Model: `gpt-5.6-terra` through the OpenAI Responses API.
- Scenarios: certified MPC; rejected MPC followed by successful predictive repair; rejected MPC followed by a declared repair timeout.
- Prompt formulations: formal execution record and operator narrative.
- Repetitions: three per formulation and scenario.
- Sample: 18 complete workflows and 30 sequential tool decisions.
- Protocol SHA-256: `8fae76b986f73c265b7bfad940214befd466d73f387b255ca55ae081e6a555f1`.

## Results

| Runtime situation | Workflows | Correct workflows | Correct decisions | Executed plan | Storage violations | Service violations |
|---|---:|---:|---:|---|---:|---:|
| MPC certified unchanged | 6 | 6 | 6/6 | Original MPC | 0 | 0 |
| MPC rejected; repair certified | 6 | 6 | 12/12 | Predictively repaired plan | 0 | 0 |
| MPC rejected; repair timeout | 6 | 6 | 12/12 | Previously verified backup | 0 | 0 |
| **Total** | **18** | **18** | **30/30** | — | **0** | **0** |

The model issued 12 `install_certified_plan`, 12 `request_predictive_repair`, and 6 `retain_verified_plan` calls. It made no attempt to install a rejected plan. Mean per-call API latency was 2.46 s in the pass scenario, 3.20 s in the successful-repair scenario, and 2.88 s in the timeout scenario. The 30 calls used 24,431 input tokens and 3,020 output tokens; all 30 response identifiers were unique.

## Transportation outcomes linked to the decisions

The live API calls determine which orchestration tool is requested. The trusted execution-authority layer then checks exact plan/verdict binding. Traffic quantities below come from the frozen, independently audited MFD replay associated with the authorized plan.

- When MPC passed, the original and certified executions were identical: 7,852.00 veh-h TTS, 200.00-vehicle peak queue, and 1,709.80 Region-1 vehicles at the deadline.
- When MPC was rejected, its replay reached a 2,180.04-vehicle queue and 2,853.08 Region-1 vehicles at the deadline, exceeding the 2,000-vehicle storage and 2,850-vehicle service limits. That plan was never executed.
- Successful repair selected `theta=0.2822265625`. Its realized replay reached a 1,618.65-vehicle peak queue and 2,260.32 Region-1 vehicles at the deadline; the certificate bounded the deadline accumulation by 2,849.10 vehicles.
- After the declared 30-second repair cutoff, the verified backup continued. Its replay reached a 197.98-vehicle peak queue and 1,727.56 Region-1 vehicles at the deadline.

The standalone evidence audit passed all checks. It independently recomputed 1,920 stress trajectories, 640 paired repair/backup comparisons, the witness integrals, the 28-point ordered repair grid, and the first certified result after 11 calls and 91.744675 s of archived computation.

## Suitable claim

In 18 live OpenAI workflows spanning two prompt formulations, the agent correctly installed an unchanged certified MPC plan, invoked predictive repair after rejection, and retained the verified backup after repair timeout. All 30 tool decisions matched the frozen orchestration policy. Exact-plan execution binding yielded zero storage or service violations in the associated certified traffic replays.

This experiment evaluates the agent--certifier interface: the model interprets trusted runtime state and chooses tools, while certification and execution authority remain deterministic and independently auditable.
