# Frozen task-state runtime v2: development-informed implementation

This version is declared after the eight v1 DEVELOPMENT calls and before any
held-out call. All v1 sources, protocols, calls and trajectories remain unchanged.
There were no v1 held-out calls. The initial-condition development grid and
selection are unchanged: the first qualifying state is the original primary
3000/3000-vehicle regional state with a 200-vehicle exterior backlog.

## Development findings and bounded corrections

The v1 structured model identified both contextual operations correctly but
included a redundant regional selector where the grammar required `unchanged`.
Strict validation rejected those requests. The new semantic protocol uses
operation-specific fields. The prose baseline retains its direct-output and
prose-memory design, and receives the same new held-out phrases and physical
information types. No retrospective v1 score is altered.

The v1 development also exposed a directional gate residual of about minus
5e-12 from a numerically feasible SLSQP candidate. All v2 arms now compile raw
candidate commands to a dyadic grid with denominator 2^40 BEFORE certification.
Clip to [0,1], round to that grid, and correct each independent paired-gate
difference to at most3/4 by splitting the excess integer units between its two
coordinates. Refuse any correction above1e-7 in maximum norm. Save raw and
compiled commands and their exact rational margins. Only the compiled commands
are certified, bound and executed; no constraint or proof tolerance is relaxed.
The same operation applies to oracle, live, constant-network, malicious-command
and matched nominal-replay arms. It modifies neither scientific kernel nor
the old studies' commands.

## Common physical contract

The seven-state field, fixed demand, literature cubic, original30% one-hour
trapezoidal arrival pulse, five-minute planning grid and one-hour mission
remain unchanged. Every current physical coordinate has a one-vehicle sound
observation half-width. The exterior-arrival residual is bounded by60vehicles/h.
The actual nominal error/residual is zero. Hard constraints include nonnegative
classes, regional capacities,2000-vehicle exterior storage, exact gate boxes and
paired-gate differences, plus Region1 at most2850vehicles at minute60.

The fixed regional objective rows remain (4,1,0,0,0,0,1) and(1,4,0,0,0,0,1);
network cost uses(1,1,0,0,0,0,1). Absolute priority expiry determines their
remaining objective windows. Every candidate covers the entire remaining hard
mission and its original deadline, regardless of the soft priority window.

## Frozen evaluation menu

- Oracle intended requests and constant-network requests, both certified.
- Original prose and structured task-state interfaces on two fresh held-out
  eight-instruction paraphrases, totaling32live calls.
- One separately labeled structured-interface corruption episode with8calls.
  At10,20,25,30minutes, the frozen memory-view transformation in the v2 semantic
  protocol supplies false Region2 active/suspended records and future expiries.
  Canonical parsed-intent history, current authenticated instruction, sensing,
  model, hard task and proof store remain unchanged.
- Matched nominal replays of all five live request sequences, reoptimizing on
  each replay's own state; these are not new interactive live episodes.
- Certified and unprotected deterministic command-pressure diagnostics. Raw
  command(0.8,0.5,0,0.75) is proposed at20,25,30,35minutes; network MPC is requested
  at the other epochs. The dyadic compiler acts on this raw command as on all
  others. The adversary bypasses economic planning in its stated command
  channel; its commands are not represented as actual LLM outputs.

The task sequence is SET R1/25 at5min, CONTINUE at10, INTERRUPT R2/15 at15,
EXTEND10 at20, RESUME at25, expiry-aware CONTINUE at30, SET R2/20 at35, CANCEL
at40. Compiled expected windows are25,20,15,20,5,0,20,0minutes. New held-out
phrases are frozen by the semantic protocol before dispatch. There is no
further prompt, schema, scenario or objective tuning on held-out results.

The eight v1 development calls plus40 v2 evaluation/intervention calls exhaust
the total48call authorization for this bounded study. Use the already-installed
local Qwen3:8b only, temperature0, fixed seeds and model digest; no download,
paid external API, hidden retry or substituted response. Each call consumes
its reserved slot even when it fails. Development performance is excluded from
held-out comparisons.

## Evidence and interpretation

The unchanged trusted proof store and authority bind each actual compiled plan
to the current sound observation, model/task contract and absolute clock. All
failed certificates retain the original proof and suffix. Stop at failed
initialization or expired authority. Logical activation remains synchronous.
Live calls use their own episode's actual physical and execution feedback.

Report all semantic, compiler, planning and certificate outcomes separately.
Compute physical/service guarantees, TTS, regional vehicle-hours, boundary delay
and peak, admissions/retention, and the common oracle time-varying task cost.
The oracle task-cost schedule is used for all trajectories, never each model's
self-selected metric; it is a finite-horizon diagnostic, not a Bellman optimum.
Correct short-horizon priorities need not minimize full-mission TTS or this
time-varying metric. Compare them honestly with constant-network operation.

For command pressure, unprotected execution can leave the declared storage
domain. Continue its equations only as an explicitly labeled mathematical
overflow diagnostic, not as a valid traffic deployment or a certified policy.
Report the first crossing separately from later overflow values and failed
recovery plans. Distinguish a failed proof from an actual physical violation.
Archive every attempt, including unfavorable results. Independent replay and
source/proof audits supply the manuscript's numerical values.
