LATEX PACKAGE - COMPLETE AND REDUCED PAPERS

Title: Formal Guarantees for Trustworthy Agent-Mediated Urban Perimeter Control
Revision: 19 October 2026. Declarations are included directly in both manuscripts.

MAIN DOCUMENTS
main.tex          Complete version.
main_reduced.tex  Reduced version.

OVERLEAF
Upload this ZIP as a new project. In the project settings, choose main.tex
or main_reduced.tex as the Main document. Select pdfLaTeX as the compiler.
Switch the Main document to compile the other version.

CONTENTS
Both manuscript sources, the shared bibliography and all required figures.
Authorship contributions, competing interests, and data/code availability
are included near the end of each main document, before the appendices.
There are no separate declaration files. Generated bibliography files are
omitted because Overleaf creates them from FOUNDATION_REFERENCES.bib.
Keep the figures folder unchanged.

The elsarticle class, elsarticle-num bibliography style and glyphtounicode
file are standard TeX-distribution files supplied by Overleaf.

LOCAL COMPILATION
With a TeX distribution containing elsarticle and the listed packages, run:
  pdflatex main
  bibtex main
  pdflatex main
  pdflatex main
For the reduced version, replace main with main_reduced in all four commands.
