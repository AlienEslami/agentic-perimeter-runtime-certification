Formal Guarantees for Trustworthy Agent-Mediated Urban Perimeter Control
Current sources - 19 October 2026

main.tex          Complete paper (87 pages).
main_reduced.tex  User-supplied reduced paper (53 pages).

Upload this ZIP to Overleaf. Choose main.tex or main_reduced.tex as the
main document and select pdfLaTeX. Keep both figures in the figures/
folder. The shared bibliography is FOUNDATION_REFERENCES.bib.
Overleaf generates the bibliography automatically; recompile as needed
to resolve references. All declarations are already inside each source.

The complete paper includes the revised proof explanations in the
reduced paper, retaining its additional appendices and experiments.
